
<?php $__env->startSection('title', 'Categorie Edit'); ?>

<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Categorie Edit</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Categories Management</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('categories')); ?>">Categories</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Categorie Edit</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('edit-category')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-edit"></i>
                                Categories Edit
                            </h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="validationCustom01">Category Name</label>
                                        <input type="text" name="category_name" class="form-control" placeholder="Enter Page Name" value="<?php echo e($getResult->category_name); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('category_name')); ?></span>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="validationCustom02">Slug</label>
                                        <input type="text" name="slug" class="form-control" placeholder="Enter Slug" value="<?php echo e($getResult->slug); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('slug')); ?></span>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">

                                        <label for="validationCustom01">Thumbnail [ 233 X 145 & 3MB ]</label>
                                        <input type="file" accept="thumbnail" name="thumbnail" class="form-control" value="<?php echo e($getResult->thumbnail); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('thumbnail')); ?></span>
                                    </div>
                                    <img style="width: 120px;" class="rounded mx-auto d-block" src="<?php echo e(asset('images/category/thumbnail/'.$getResult->thumbnail)); ?>" alt="">
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="validationCustom01">Banner [ 1202 X 340 & 5MB ]</label>
                                        <input type="file" name="banner" class="form-control" title="Choose a video please" value="<?php echo e($getResult->banner); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('banner')); ?></span>
                                    </div>
                                    <img style="width: 150px; height: 70px" class="rounded mx-auto d-block" src="<?php echo e(asset('images/category/banner/'.$getResult->banner)); ?>" alt="">
                                </div>

                                <input type="hidden" name="id" value="<?php echo e(Crypt::encrypt($getResult->id)); ?>">
                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/pages/categories/edit-categories.blade.php ENDPATH**/ ?>