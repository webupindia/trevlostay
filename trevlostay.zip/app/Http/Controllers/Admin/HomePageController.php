<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Banner;
use App\Model\Supplier;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;

class HomePageController extends Controller
{
   public function getAll(){

        $SupplierName  = Supplier::all();
        $Banner = Banner::latest()->orderBy('id', 'desc')->get();
        if(count($Banner)>0){
            return view('admin.pages.home-page.banner',['Banner'=>$Banner,'SupplierName'=>$SupplierName]);
        } else {
            connectify('error', 'Ooops 🙁', 'No Data Found ');
             return view('admin.pages.home-page.banner',['Banner'=>$Banner,'SupplierName'=>$SupplierName]);
        }
    }
  
     public function AddBanner(Request $request)
    {
    	 $this->validate($request, [
                'name'        => 'required|unique:Banner',
                'type'        => 'required',
                'caption'     => 'required',
                'banner'      => 'mimes:jpeg,jpg,png,mp4,ogx,oga,ogv,ogg,webm', 
              ]);

            if($request->hasFile('banner')) {
               	$fileName = time().'.'.$request->banner->extension();  
                $request->banner->move(public_path('images/home/banner'), $fileName);
                $banner = $fileName;
            }

	    	  $result = new Banner();

	        $result->name        = $request['name'];
	        $result->type        = $request['type'];
	        $result->caption     = $request['caption'];
	        $result->banner      = $banner;

	     if($result->save())
	        {
	            connectify('success', 'Haa Haa 😊 ', 'Add New Banner  Created 😊 Successfully.');
	            return redirect()->route('banner')->with('success','😊 Add New Banner Created  😊 Successfully 😊');
	        }
	        else
	        { 
	        	connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
	        	return redirect()->back()->with('error' ,'🙁 Something went wrong!!🙁 Please Try again 🙁');
	        } 
    }
     public function editBanner($id)
    {

       try {
           $decrypted    = Crypt::decrypt($id);
           $getResult    = Banner::where('Id',$decrypted)->first();
           $getResults   = Banner::select('id')->latest()->get();

           if(!is_null($getResult)){
            return view('admin.pages.home-page.edit-banner',['getResult'=>$getResult,'getResults'=>$getResults]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
     public function putBanner(Request $request)
    {
        $this->validate($request, [
                'name'        => 'required',
                'type'        => 'required',
                'caption'     => 'required',
                'banner'      => 'nullable|mimes:jpeg,jpg,png,mp4,ogx,oga,ogv,ogg,webm', 
         ]);

        $id                = Crypt::decrypt($request['id']);
        $name              = strip_tags($request['name']);
        $type              = strip_tags($request['type']);
        $caption           = strip_tags($request['caption']);

        $Banner = Banner::find($id);

     if($request->banner != ''){        
          $path = public_path().'/images/home/banner\\';

          //code for remove old file
          if($Banner->banner != ''  && $Banner->banner != null){
               $file_old = $path.$Banner->banner;
               unlink($file_old);
          }
          //upload new file
          $file = $request->banner;
          $filename =  time().'.'.$file->extension();
          $file->move($path, $filename);
          //for update in table
          $Banner->update(['banner' => $filename]);
        }

        Banner::where('id',$id)->update([
            'name'         => $name,
            'type'         => $type,
            'caption'      => $caption,
        ]);
             connectify('success', 'Haa Haa 😊 ', ' Banner Updated 😊 Successfully.'); 
            return redirect()->route('banner')->with('success','Banner Updated 😊 Successfully');
    }

     public function deleteBanner($id)
    {
        $id         =   Crypt::decrypt($id);
        $Banner =   Banner::findOrFail($id);
       
        $banner_path = public_path("/images/home/banner\\") .$Banner->banner;
      
            if(File::exists($banner_path)) {
                File::delete($banner_path);
            }else{
                  $Banner->delete();
            }
          $Banner->delete();

        if($Banner){
             connectify('success', 'success ', '😪 ​​​​​ Banner has been deleted Successfully.😪');
            return redirect()->back()->with('success','  Banner has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
     public function changeBannerStatus(Request $request)
    {
        $user = Banner::find($request->user_id);
        $user->status = $request->status;
       $user->save();
        smilify('success', 'Status successfully Update');
       return response()->json(['success' => 'Status successfully Update']);

    }
}
