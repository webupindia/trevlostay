<?php

namespace App\Http\Controllers\Supplier;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Vouchers\VoucherCategories;
use App\Model\Vouchers\VoucherTypes;
use App\Model\Vouchers\Vouchers;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class VouchersController extends Controller
{

    /*------------Vouchers----------------*/
      public function getAllVouchers()
    {   
        $supplier= Auth::guard('supplier')->user()->id;
        $Vouchers   = Vouchers::latest()->where('supplier_id', $supplier)->orderBy('id', 'desc')->get();

        if(count($Vouchers)>0){
            return view('supplier.pages.vouchers.vouchers',['Vouchers'=>$Vouchers]);
        } else {
           connectify('error', 'Ooops 🙁', 'No Data Found ');
            return view('supplier.pages.vouchers.vouchers',['Vouchers'=>$Vouchers]);
        }
    }
      public function getCategoryTypeId()
    {
         $countries = DB::table('countries')->get();
        $Types = VoucherTypes::latest()->orderBy('id', 'desc')->get();
        $Categories = VoucherCategories::latest()->orderBy('id', 'desc')->get();
        if(count($Categories)>0){
            return view('supplier.pages.vouchers.create-voucher',['Categories'=>$Categories,'Types'=>$Types,'countries'=>$countries]);
        } else {
           connectify('error', 'Ooops 🙁', 'No Data Found ');
            return view('supplier.pages.vouchers.categories',['Categories'=>$Categories,'Types'=>$Types]);
        }
    }

     public function CreateVoucher(Request $request)
    {
       $this->validate($request, [
                'category_id'      => 'required',
                'types_id'         => 'required',
                'name'             => 'required|min:2|unique:Vouchers',
                'code'             => 'required|min:5',
                'countries_id.*'   => 'required',        
                'price'            => 'required|integer',  
                'discount_value'   => 'required',    
                'details'          => 'required',    
                'currency'         => 'required',    
                'term_condition'   => 'required',   
                'expiry_date_from' => 'required',   
                'expiry_date_to'   => 'required',   
                'voucher_qty'      => 'required',    
                'images'           => 'required|mimes:jpg,jpeg,png|max:3072'
              ]);

       if (Auth::guard('supplier')->user()) 
             {
               $supplier_id = Auth::guard('supplier')->user()->id;
             }
          else
             {
               $supplier_id = 0;
             }

      $result = new Vouchers();

        $result->category_id           = $request['category_id'];
        $result->types_id              = $request['types_id'];
        $result->supplier_id           = $supplier_id;
        $result->name                  = $request['name'];
        $result->code                  = $request['code'];
        $result->countries_id          = implode(',', $request['countries_id']);
        $result->price                 = $request['price'];
        $result->discount_value        = $request['discount_value'];
        $result->details               = $request['details'];
        $result->currency              = $request['currency'];
        $result->term_condition        = $request['term_condition'];
        $result->expiry_date_from      = $request['expiry_date_from'];
        $result->expiry_date_to        = $request['expiry_date_to'];
        $result->voucher_qty           = $request['voucher_qty'];
        $images                        = time().'.'.$request->images->extension();  
        $result->images                =   $images;

        if($result->save())
        {
             $request->images->move(public_path('images/vouchers'), $images);
            connectify('success', 'Haa Haa 😊 ', ' Voucher Created 😊 Successfully.');
            return redirect()->route('supplier-vouchers')->with('success','😊 Voucher Created 😊 Successfully 😊');
        }
        else
        {
            connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
          return redirect()->back()->with('error' ,'🙁 Something went wrong!!🙁 Please Try again 🙁');
        }
    }
     public function editVoucherView($id)
    {

       try {
           $decrypted    = Crypt::decrypt($id);
           $getResult    = Vouchers::where('Id',$decrypted)->first();
           $getResults   = Vouchers::select('id')->latest()->get();
           $Types        = VoucherTypes::all();
           $Categories   = VoucherCategories::all();
           $countries    = DB::table('countries')->get();

           if(!is_null($getResult)){
            return view('supplier.pages.vouchers.edit-voucher',['getResult'=>$getResult,'getResults'=>$getResults,'Types'=>$Types,'Categories'=>$Categories,'countries'=>$countries]);
           } else {
             connectify('error', 'Ooops 🙁', 'Oops ! No Data found for specific id');
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
     public function putVoucher(Request $request)
    {
        $this->validate($request, [
                'category_id'      => 'required',
                'types_id'         => 'required',
                'name'             => 'required|min:2',
                'code'             => 'required|min:5',
                'countries_id.*'   => 'required',      
                'price'            => 'required|integer',  
                'discount_value'   => 'required',    
                'details'          => 'required',    
                'currency'         => 'required',    
                'term_condition'   => 'required',   
                'expiry_date_from' => 'required',   
                'expiry_date_to'   => 'required',    
                'voucher_qty'      => 'required',
                'images'           => 'nullable|mimes:jpg,jpeg,png|max:3072'    
               
         ]);

        $id                      = Crypt::decrypt($request['id']);
        $category_id             = strip_tags($request['category_id']);
        $types_id                = strip_tags($request['types_id']);
        $name                    = strip_tags($request['name']);
        $code                    = strip_tags($request['code']);
        $countries_id            = implode(',', $request['countries_id']);
        $price                   = strip_tags($request['price']);
        $discount_value          = strip_tags($request['discount_value']);
        $details                 = strip_tags($request['details']);
        $currency                = strip_tags($request['currency']);
        $term_condition          = strip_tags($request['term_condition']);
        $expiry_date_from        = strip_tags($request['expiry_date_from']);
        $expiry_date_to          = strip_tags($request['expiry_date_to']);
        $voucher_qty             = strip_tags($request['voucher_qty']);
      
         $Vouchers = Vouchers::find($id);

     if($request->images != ''){        
          $path = public_path().'/images/vouchers\\';

          //code for remove old file
          if($Vouchers->images != ''  && $Vouchers->images != null){
               $file_old = $path.$Vouchers->images;
               unlink($file_old);
          }
          //upload new file
          $file = $request->images;
          $filename =  time().'.'.$file->extension();
          $file->move($path, $filename);
         
         Vouchers::where('id',$id)->update(['images' => $filename]);
        }

        $updateVoucher       = Vouchers::where('id',$id)->update([
            'category_id'    => $category_id,
            'types_id'       => $types_id,
            'name'           => $name,
            'code'           => $code,
            'countries_id'   => $countries_id,
            'price'          => $price,
            'discount_value' => $discount_value,
            'details'        => $details,
            'currency'       => $currency,
            'term_condition'     => $term_condition,
            'expiry_date_from'   => $expiry_date_from,
            'expiry_date_to'     => $expiry_date_to,
            'voucher_qty'        => $voucher_qty,
           
        ]);

            connectify('success', 'Haa Haa 😊 ', ' Voucher Updated 😊 Successfully.'); 
            return redirect()->route('supplier-vouchers')->with('success','Voucher Updated 😊 Successfully');
    }

      public function deleteVoucher($id)
    {
        $id         =   Crypt::decrypt($id);
        $Vouchers =   Vouchers::findOrFail($id);
       
        $images_path = public_path("/images/vouchers\\") .$Vouchers->images;
       
            if(File::exists($images_path)) {
                File::delete($images_path);
            }else{
               $Vouchers->delete();
            }
            
          $Vouchers->delete();

        if($Vouchers){
             connectify('success', 'success ', '😪 ​​​​​ Voucher has been deleted Successfully.😪');
            return redirect()->back()->with('success',' Voucher has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
    
}
