@extends('admin.layouts.master')
@section('title', 'Create Advertisement')
@section('content')
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Create Advertisement</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Advertisement Management</a></li>
                    <li class="breadcrumb-item"><a href="{{route('advertisement')}}">Advertisement</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Create Advertisement</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="#" method="post" enctype="multipart/form-data">
                            @csrf
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-address-book-o"></i>
                                Create New Advertisement
                            </h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="validationCustom01">Advertisement Name</label>
                                        <input type="text" name="category_name" class="form-control" placeholder="Enter Category Name " value="{{old('category_name')}}" required="">
                                        <span class="text-danger">{{ $errors->first('category_name') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="validationCustom01">Type</label>
                                        <select name="category_id" id="category_id" class="form-control" onchange="yesnoCheck(this);" required="">
                                          
                                            <option value="">Choose Type</option>
                                            <option value="video">Video</option>
                                            <option value="images">Images</option>
                                          
                                        </select>
                                        <span class="text-danger">{{ $errors->first('slug') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-6" id="video" style="display: none;">
                                    <div class="form-group " >
                                        <label for="validationCustom01">Video [ 233 X 145 & 3MB ]</label>
                                        <input type="file" name="thumbnail" class="form-control" value="{{old('thumbnail')}}" required="">
                                        <span class="text-danger">{{ $errors->first('thumbnail') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-6" id="images" style="display: none;">
                                    <div class="form-group" >
                                        <label for="validationCustom01">Images [ 1202 X 340 & 5MB ]</label>
                                        <input type="file" name="images[]" class="form-control" value="{{old('banner')}}">
                                        <span class="text-danger">{{ $errors->first('banner') }}</span>
                                    </div>
                                </div>
                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

@endsection

@push('page-script')
<script>
    function yesnoCheck(that) {
    if (that.value == "video") {
 
        document.getElementById("video").style.display = "block";
    } else {
        document.getElementById("video").style.display = "none";
    }
     if (that.value == "images") {
 
        document.getElementById("images").style.display = "block";
    } else {
        document.getElementById("images").style.display = "none";
    }
}
</script>
@endpush