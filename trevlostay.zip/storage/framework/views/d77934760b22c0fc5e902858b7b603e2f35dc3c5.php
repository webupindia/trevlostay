
<?php $__env->startSection('title', 'Products Pages'); ?>
<?php $__env->startPush('page-style'); ?>
<!--Data Tables -->
<link href="<?php echo e(asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<!--Switchery-->
<link href="<?php echo e(asset('admin/plugins/switchery/css/switchery.min.css')); ?>" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<link href="<?php echo e(asset('admin/plugins/bootstrap-switch/bootstrap-switch.min.css')); ?>" rel="stylesheet">

<style type="text/css">
    .dropdown-item:hover {
        background-color: grey;
    }

</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-8">
                <h4 class="page-title">Products</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Products Management</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Products</li>
                </ol>
            </div>
            <div class="col-sm-4">
                <div class="btn-group float-sm-right">
                    <a href="<?php echo e(route('add-product')); ?>" class="btn btn-light waves-effect waves-light">Add New Product</a>
                </div>
            </div>
        </div>
        <!-- End Breadcrumb-->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> All Products</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Product Images</th>
                                        <th>Product Name</th>
                                        <th>Author</th>
                                        <th>Category</th>
                                        <th>Sale Amount</th>
                                        <th>Offer Amount</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="deleteRow">
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $Productimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $Productimagess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($Productimagess->product_id == $Product['id']): ?>
                                            <span class="dropdown">
                                                <img src="<?php echo e(asset('images/products/'.$Productimagess->product_img )); ?>" class="img-hover" alt="" height="50px" width="50px">
                                            </span>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>

                                        <td><?php echo e($Product->name); ?></td>

                                        <?php if(!(empty($Product->supplier_id))): ?>
                                        <?php $__currentLoopData = $SupplierName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key4 => $SupplierNames): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($Product->supplier_id == $SupplierNames['id']): ?>
                                        <td><?php echo e($SupplierNames->name); ?></td>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <td>Admin</td>
                                        <?php endif; ?>

                                        <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key5 => $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($Product->category_id == $Category['id']): ?>
                                        <td><?php echo e($Category->category_name); ?></td>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <td><del><?php echo e($Product->sale_amount); ?></del> &#36;</td>

                                        <td><?php echo e($Product->offer_amount); ?> &#36;</td>

                                        <td>
                                            <input data-id="<?php echo e($Product->id); ?>" class="js-switch" type="checkbox" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="InActive" data-color="#14b6ff" <?php echo e($Product->status ? 'checked' : ''); ?> >
                                        </td>

                                        <td>
                                            <div class="dropdown">
                                                <a href="javascript:void();" class="dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown">
                                                    <i class="icon-options"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="<?php echo e(route('product-review/{id}',['id'=>Crypt::encrypt($Product->id)])); ?>" title="View Review">View Review </a>

                                                    <a class="dropdown-item" href="<?php echo e(route('product-rating/{id}',['id'=>Crypt::encrypt($Product->id)])); ?>" title="View Review">View Rating</a>

                                                    <a class="dropdown-item " href="<?php echo e(route('edit-product/{id}',['id'=>Crypt::encrypt($Product->id)])); ?>" title="Edit Product">Edit Product</a>

                                                    <a class="dropdown-item button" href="#" data-id="<?php echo e($Product->id); ?>" title="Delete Product">Delete Product</a>

                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
<!--Data Tables js-->
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')); ?>"></script>
<!--Switchery Js-->
<script src="<?php echo e(asset('admin/plugins/switchery/js/switchery.min.js')); ?>"></script>
<!--Bootstrap Switch Buttons-->
<script src="<?php echo e(asset('assets/plugins/bootstrap-switch/bootstrap-switch.min.js')); ?>"></script>
<script>
    var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
    $('.js-switch').each(function() {
        new Switchery($(this)[0], $(this).data());
    });

</script>

<script>
    $(function() {
        $('.js-switch').change(function() {
            var status = $(this).prop('checked') == true ? 1 : 0;
            var user_id = $(this).data('id');

            $.ajax({
                type: "GET",
                dataType: "json",
                url: 'change-product-status',
                data: {
                    'status': status,
                    'user_id': user_id
                },
                success: function(data) {
                    console.log(data.success)

                    location.reload();
                }
            });
        })
    })

</script>
<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();

    });

</script>
<script src="<?php echo e(asset('admin/plugins/alerts-boxes/js/sweetalert.min.js')); ?>"></script>
<script type="text/javascript">
    $(document).on('click', '.button', function(e) {
        e.preventDefault();
        var id = $(this).data('id');
        var whichtr = $(this).closest("#deleteRow");
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this file!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        type: "GET",
                        url: "destroy",
                        data: {
                            id: id
                        },
                        success: function(data) {
                            swal("Poof! Your Data has been deleted!", {
                                icon: "success",
                            });
                            $(whichtr).remove();
                        }
                    });
                } else {
                    swal("Your imaginary file is safe!");
                }

            });
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/pages/products/products.blade.php ENDPATH**/ ?>