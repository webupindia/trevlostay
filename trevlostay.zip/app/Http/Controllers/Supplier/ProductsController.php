<?php

namespace App\Http\Controllers\Supplier;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Products;
use App\Model\Categories;
use App\Model\Supplier;
use App\Model\Productimg;
use App\Model\Offerimg;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

class ProductsController extends Controller
{
    public function getAllProducts()
    {
        
        $Productimage  = Productimg::all();
         $Categories    = Categories::all();
        $supplier= Auth::guard('supplier')->user()->id;
        $Products = Products::latest()
         ->where('type','Single')
        ->where('supplier_id', $supplier)->get();
        if(count($Products)>0){
            return view('supplier.pages.products.products',['Products'=>$Products,'Productimage'=>$Productimage,'Categories'=>$Categories]);
        } else {
        	 connectify('error', 'Ooops 🙁', 'No Data Found ');
            return view('supplier.pages.products.products',['Products'=>$Products,'Productimage'=>$Productimage,'Categories'=>$Categories]);
        }
    }
       public function add () {
        $categories = Categories::all();
        $supplier = Supplier::all();
        return view('supplier.pages.products.add-product', ['categories' => $categories,'Supplier' => $supplier ]);
    }


	public function AddProduct(Request $request)
    {
    	 $this->validate($request, [
                'category_id'      => 'required',
                'name'             => 'required|min:3|unique:products',
                'slug'             => 'required|min:5|unique:products',
                'sale_amount'      => 'required|numeric',
                'offer_amount'     => 'required|numeric',
                'type'             => 'required',
                'availability'     => 'required',
                'term_condition'   => 'required|min:5',
                'product_details'  => 'required|min:5',
                'product_img.*'     => 'mimes:jpeg,jpg,png|max:2048',
               
              ]);
           
          if (Auth::guard('supplier')->user()) 
             {
               $status = 0;
               $supplier_id = Auth::guard('supplier')->user()->id;
             }
          else
             {
       
               $status = 1;
               $supplier_id = 0;
             }
          
	       	$result = new Products();
          $result->category_id    = $request['category_id'];
          $result->supplier_id    = $supplier_id;
          $result->name           = $request['name'];
          $result->slug           = $request['slug'];
          $result->sale_amount    = $request['sale_amount'];
          $result->offer_amount   = $request['offer_amount'];
          $result->type           = $request['type'];
          $result->availability   = $request['availability'];
          $result->status         = $status;
          $result->term_condition       = $request['term_condition'];
          $result->product_details      = $request['product_details'];

          if($result->save())
          {
               $images      =  array();
              if($files = $request->file('product_img'))
              {
                  foreach($files as $file) 
                  {
                     $productimgname     =   time().rand(1,100).'.'.$file->extension();
                     $destinationPath = public_path('images/products');

                      if($file->move($destinationPath, $productimgname))
                      {
                          $images[]   =   $productimgname;
                          $saveResult   =   Productimg::create([
                            'product_id' =>  $result->id,
                            'product_img' => $productimgname,
                          ]);   
                      }
                  }
              }
	            connectify('success', 'Haa Haa 😊 ', 'New Product  Added 😊 Successfully.');
	            return redirect()->route('supplier-products')->with('success','😊 New Product  Added  Created  😊 Successfully 😊');
	        }
	        else
	        { 
	        	connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
	        	return redirect()->back()->with('error' ,'🙁 Something went wrong!!🙁 Please Try again 🙁');
	        }
       
    }
       public function editProductView($id)
    {

       try {
           $decrypted    = Crypt::decrypt($id);
           $getResult    = Products::where('Id',$decrypted)->first();
           $getResults   = Products::select('id')->latest()->get();
           $categories   = Categories::all();
          $Productimage  = Productimg::all();

           if(!is_null($getResult)){
            return view('supplier.pages.products.edit-product',['getResult'=>$getResult,'getResults'=>$getResults,'categories' => $categories,'Productimage'=>$Productimage]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
        public function putProduct(Request $request)
    {
        $this->validate($request, [
                'category_id'      => 'required',
                'name'             => 'required|min:3',
                'slug'             => 'required|min:5',
                'sale_amount'      => 'required',
                'offer_amount'     => 'required',
                'type'             => 'required',
                'availability'     => 'required',
                'term_condition'   => 'required|min:5',
                'product_details'  => 'required|min:5',
                'product_img.*'    => 'mimes:jpeg,jpg,png|max:2048', 
         ]);
        $id                = Crypt::decrypt($request['id']);
        $category_id       = strip_tags($request['category_id']);
        $name              = strip_tags($request['name']);
        $slug              = strip_tags($request['slug']);
        $sale_amount       = strip_tags($request['sale_amount']);
        $offer_amount      = strip_tags($request['offer_amount']);
        $type              = strip_tags($request['type']);
        $term_condition    = strip_tags($request['term_condition']);
        $availability      = strip_tags($request['availability']);
        $product_details   = $request['product_details'];

        $updatePage  = Products::where('id',$id)->update([
            'category_id'     => $category_id,
            'name'            => $name,
            'sale_amount'     => $sale_amount,
            'offer_amount'    => $offer_amount,
            'type'            => $type,
            'slug'            => $slug,
            'availability'    => $availability,
            'term_condition'   => $term_condition,
            'product_details'  => $product_details,
        ]);

        if($updatePage){
           $images      =  array();
              if($files = $request->file('product_img'))
              {
                  foreach($files as $file) 
                  {
                     $productimgname     =   time().rand(1,100).'.'.$file->extension();
                     $destinationPath = public_path('images/products');

                      if($file->move($destinationPath, $productimgname))
                      {
                          $images[]   =   $productimgname;
                          $saveResult   =   Productimg::create([
                            'product_id' =>   $id,
                            'product_img' => $productimgname,
                          ]);   
                      }
                  }
              }
             connectify('success', 'Haa Haa 😊 ', ' Product Updated 😊 Successfully.'); 
            return redirect()->route('supplier-products')->with('success','Product Updated 😊 Successfully');
        } else{
            connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
      public function deleteProduct($id)
    {
        $id         =   Crypt::decrypt($id);
        $Restricted =   Products::where('id',$id)->delete();

        if($Restricted){
             connectify('success', 'success ', '😪 ​​​​​ Product has been deleted Successfully.😪');
            return redirect()->back()->with('success',' Product has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
         public function deleteProductImg($id)
    {
            $id          =   Crypt::decrypt($id);
            $Restricted         = Productimg::findOrFail($id);
            $image_path         = public_path("\images\products\\") .$Restricted->product_img;
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
            else{
                $Restricted->delete();
            }
            $Restricted->delete();
        if($Restricted){
             connectify('success', 'success ', '😪 ​​​​​ Product Image has been deleted Successfully.😪');
            return redirect()->back()->with('success','  Product Image has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
        /*---------Reviews---------*/
     public function ProductReviews($id)
    {
       try {
            $decrypted   = Crypt::decrypt($id);
            $Products    = Products::where('id',$decrypted)->first();
            $Reviews = DB::table('reviews')
             ->join('users', 'reviews.user_id', '=', 'users.id')
             ->select('reviews.*', 'users.name')
             ->where('product_id', $decrypted)
             ->get();
            $Allproduct  = Products::all(); 
    
           if(!is_null($Reviews)){
            return view('supplier.pages.products.reviews.reviews',['Reviews'=>$Reviews,'Products'=>$Products,'Allproduct'=>$Allproduct]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
      
        /*---------Ratings---------*/
            public function ProductRatings($id)
    {
       try {
            $decrypted   = Crypt::decrypt($id);
            $Products    = Products::where('id',$decrypted)->first();
            $Rating = DB::table('rating')
             ->join('users', 'rating.user_id', '=', 'users.id')
             ->select('rating.*', 'users.name')
             ->where('product_id', $decrypted)
             ->get();
           $Allproduct  = Products::all(); 
       
         
           if(!is_null($Rating)){
            return view('supplier.pages.products.rating.rating',['Rating'=>$Rating,'Products'=>$Products,'Allproduct'=>$Allproduct]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }   

}
