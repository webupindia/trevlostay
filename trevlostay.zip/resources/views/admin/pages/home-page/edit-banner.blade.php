@extends('admin.layouts.master')
@section('title', 'Edit Banner')

@section('content')
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Edit Banner</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Home Management</a></li>
                    <li class="breadcrumb-item"><a href="{{route('banner')}}">Banner</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Banner</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="{{ route('edit-banner') }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-edit"></i>
                                Edit Banner
                            </h4>
                            <div class="row">
                                    <div class="col-md-6">
                            <div class="form-group">
                                <label for="validationCustom01">Banner Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Enter Advertisement Name " value="{{ $getResult->name }}">
                                <span class="text-danger">{{ $errors->first('name') }}</span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="validationCustom01">Type</label>
                                <select name="type" id="type" class="form-control" onchange="yesnoCheck(this);">

                                    <option value="">Choose Type</option>
                                    <option value="videos" @if ($getResult->type =="videos" ) {{ 'selected' }} @endif>Videos</option>
                                    <option value="images" @if ($getResult->type =="images" ) {{ 'selected' }} @endif>Images</option>

                                </select>
                                <span class="text-danger">{{ $errors->first('type') }}</span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group ">
                                <label for="validationCustom01">Images Or Videos</label>
                                <input type="file" name="banner" class="form-control" value="{{ $getResult->banner }}">
                                <span class="text-danger">{{ $errors->first('banner') }}</span>
                            </div>
                              @if ($getResult->type == 'images')
                                            <img src="{{asset('images/home/banner/'.$getResult->banner)}}" class="d-block m-auto" width="100px" height="50px"/>
                                            @else
                                            <video autoplay width="80" class="d-block m-auto">
                                                <source src="{{asset('images/home/banner/'.$getResult->banner)}}" type="video/mp4">
                                            </video>
                                            @endif
                        </div>


                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputPassword" class="">Caption</label>
                                <div class="position-relative">
                                    <textarea rows="4" class="form-control" name="caption">{{ $getResult->caption }}
                                    </textarea>

                                    <span class="text-danger">{{ $errors->first('caption') }}</span>
                                </div>

                            </div>
                        </div>

                                <input type="hidden" name="id" value="{{Crypt::encrypt($getResult->id)}}">
                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

@endsection

