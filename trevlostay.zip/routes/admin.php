<?php

use Illuminate\Support\Facades\Route;


/*-------------Admin----------------*/

Route::get('/ts-admin', 'Admin\AuthController@checkLogin')->name('ts-admin');

Route::post('/login', 'Admin\AuthController@postLogin')->name('login'); 

Route::group(['middleware' => ['admin'],'prefix'=>'admin'], function () { 
Route::get('/dashboard', 'Admin\AuthController@index')->name('dashboard');
Route::get('/logout', 'Admin\AuthController@getLogout')->name('logout');

Route::get('/user-profile', function () {
  return view('admin.auth.user-profile');
})->name('profile');

Route::post('/changePassword', 'Admin\AuthController@changePassword')
       ->name('changePassword');

Route::post('/change-profile',[
  'uses' => 'Admin\AuthController@changeProfile',
  'as'    =>'change-profile'
]);

Route::get('/setting', function () {
  return view('admin.setting');
})->name('setting');

Route::post('/setting',[
  'uses' => 'Admin\AppsettingController@Themes',
  'as'    =>'setting'
]);

Route::post('/appsetting',[
  'uses' => 'Admin\AppsettingController@AppSetting',
  'as'    =>'appsetting'
]);    
/*===========Pages=============*/

Route::get('/customers',[
  'uses' => 'Admin\UserController@getAllCustomer',
  'as'    =>'customers'
]);

Route::get('/create-customer', function () {
  return view('admin.pages.add.create-customer');
})->name('create-customer');

Route::post('/create-customer',[
  'uses' => 'Admin\UserController@CreateCustomer',
  'as'    =>'create-customer'
]);


Route::get('edit-customer/{id}', [
  'uses' => 'Admin\UserController@editCustomerView',
  'as' => 'edit-customer/{id}'
 ]);

Route::post('edit-customer', [
  'uses' => 'Admin\UserController@putCustomer',
    'as' => 'edit-customer'
 ]);

Route::get('delete-customer/{id}', [
  'uses' => 'Admin\UserController@deleteCustomer',
  'as' => 'delete-customer/{id}'
 ]);
/*-------Supplier Curd---------*/
Route::get('/suppliers',[
  'uses' => 'Admin\UserController@getAllsuppliers',
  'as'    =>'suppliers'
]);

Route::get('/create-supplier', function () {
  return view('admin.pages.add.create-supplier');
})->name('create-supplier');


Route::post('/create-supplier',[
  'uses' => 'Admin\UserController@CreateSupplier',
  'as'    =>'create-supplier'
]);

Route::get('edit-supplier/{id}', [
  'uses' => 'Admin\UserController@editSupplierView',
  'as' => 'edit-supplier/{id}'
 ]);

Route::post('edit-supplier', [
  'uses' => 'Admin\UserController@putSupplier',
    'as' => 'edit-supplier'
 ]);

Route::get('delete-supplier/{id}', [
  'uses' => 'Admin\UserController@deleteSupplier',
  'as' => 'delete-supplier/{id}'
 ]);

Route::get('changeStatus', 'Admin\UserController@ChangeUserStatus');

/*-------Statics Pages-------*/
Route::get('/static-pages',[
  'uses' => 'Admin\StaticPagesController@getAllPages',
  'as'    =>'static-pages'
]);

Route::get('/create-page', function () {
  return view('admin.pages.static-pages.create-page');
})->name('create-page');


Route::post('/create-page',[
  'uses' => 'Admin\StaticPagesController@CreatePage',
  'as'    =>'create-page'
]);

Route::get('edit-page/{id}', [
  'uses' => 'Admin\StaticPagesController@editPageView',
  'as' => 'edit-page/{id}'
 ]);

Route::post('edit-page', 'Admin\StaticPagesController@putPage')->name('edit-page');
Route::get('delete-page/{id}', 'Admin\StaticPagesController@deletePage')->name('delete-page/{id}');

/*-----Categories Management-------*/
Route::get('/categories', 'Admin\CategoriesController@getAllCategories')->name('categories');
Route::get('/create-category', function () {
  return view('admin.pages.categories.create-category');
})->name('create-category');
Route::post('create-category', 'Admin\CategoriesController@CreateCategory')->name('create-category');
Route::get('edit-category/{id}', 'Admin\CategoriesController@editCategoryView')->name('edit-category/{id}');
Route::post('edit-category', 'Admin\CategoriesController@putCategory')->name('edit-category');
Route::get('delete-category/{id}', 'Admin\CategoriesController@deleteCategory')->name('delete-category/{id}');

/*-----Product Management-------*/
Route::get('/products', 'Admin\ProductsController@getAllProducts')->name('products');
Route::get('/add-product', 'Admin\ProductsController@add')->name('add-product');
Route::post('add-product', 'Admin\ProductsController@AddProduct')->name('add-product');
Route::get('edit-product/{id}', 'Admin\ProductsController@editProductView')->name('edit-product/{id}');
Route::post('edit-product', 'Admin\ProductsController@putProduct')->name('edit-product');
Route::get('delete-product/{id}', 'Admin\ProductsController@deleteProduct')->name('delete-product/{id}');
Route::get('delete-product-image/{id}', 'Admin\ProductsController@deleteProductImg')->name('delete-product-image/{id}');
Route::get('change-product-status', 'Admin\ProductsController@changeProductStatus');
/*-------------Product Reviews----------------*/
Route::get('product-review/{id}', 'Admin\ProductsController@ProductReviews')->name('product-review/{id}');
Route::get('edit-product-review/{id}', 'Admin\ProductsController@EditReviews')->name('edit-product-review/{id}');
Route::post('edit-product-review', 'Admin\ProductsController@putProductReview')->name('edit-product-review');
Route::get('delete-product-review/{id}', 'Admin\ProductsController@deleteProductReview')->name('delete-product-review/{id}');
/*-------------Product Rating----------------*/
Route::get('product-rating/{id}', 'Admin\ProductsController@ProductRatings')->name('product-rating/{id}');
Route::get('edit-product-rating/{id}', 'Admin\ProductsController@EditRatings')->name('edit-product-rating/{id}');
Route::post('edit-product-rating', 'Admin\ProductsController@putProductRatings')->name('edit-product-rating');
Route::get('delete-product-rating/{id}', 'Admin\ProductsController@deleteProductRatings')->name('delete-product-rating/{id}');
/*---------------Combo Product------------------*/
Route::get('/combo-products', 'Admin\ComboProductController@getAllComboProducts')->name('combo-products');
Route::get('/add-combo-product', 'Admin\ComboProductController@add')->name('add-combo-product');
Route::post('add-combo-product', 'Admin\ComboProductController@AddComboProduct')->name('add-combo-product');
Route::get('edit-combo-product/{id}', 'Admin\ComboProductController@editComboProductView')->name('edit-combo-product/{id}');
Route::post('edit-combo-product', 'Admin\ComboProductController@putComboProduct')->name('edit-combo-product');
Route::get('delete-combo-product/{id}', 'Admin\ComboProductController@deleteComboProduct')->name('delete-combo-product/{id}');
/*------------End Page---------*/
/*----------Vouchers Management----------------*/
Route::get('/vouchers', 'Admin\VouchersController@getAllVouchers')->name('vouchers');
Route::get('/create-voucher', 'Admin\VouchersController@getCategoryTypeId')->name('create-voucher');
Route::post('/create-voucher', 'Admin\VouchersController@CreateVoucher')->name('create-voucher');
Route::get('/edit-voucher/{id}', 'Admin\VouchersController@editVoucherView')->name('edit-voucher/{id}');
Route::post('/edit-voucher', 'Admin\VouchersController@putVoucher')->name('edit-voucher');
Route::get('delete-voucher/{id}', 'Admin\VouchersController@deleteVoucher')->name('delete-voucher/{id}');
Route::get('change-voucher-status', 'Admin\VouchersController@changeVoucherStatus');
Route::get('change-voucher-featured', 'Admin\VouchersController@changeVoucherFeatured');
/*------------Categories----------------*/
Route::get('/voucher-categories', 'Admin\VouchersController@getAllCategories')->name('voucher-categories');
Route::get('/create-voucher-category', function () {
  return view('admin.pages.vouchers.create-category');
})->name('create-voucher-category');
Route::post('/create-voucher-category', 'Admin\VouchersController@CreateCategory')->name('create-voucher-category');
Route::get('edit-voucher-category/{id}', 'Admin\VouchersController@editCategoryView')->name('edit-voucher-category/{id}');
Route::post('edit-voucher-category', 'Admin\VouchersController@putCategory')->name('edit-voucher-category');
Route::get('delete-voucher-category/{id}', 'Admin\VouchersController@deleteCategory')->name('delete-voucher-category/{id}');
/*------------Types----------------*/
Route::get('/create-voucher-types', function () {
  return view('admin.pages.vouchers.create-type');
})->name('create-voucher-types');
Route::post('/create-voucher-type', 'Admin\VouchersController@CreateType')->name('create-voucher-type');
Route::get('edit-voucher-type/{id}', 'Admin\VouchersController@editTypeView')->name('edit-voucher-type/{id}');
Route::post('edit-voucher-type', 'Admin\VouchersController@putType')->name('edit-voucher-type');
Route::get('delete-voucher-type/{id}', 'Admin\VouchersController@deleteType')->name('delete-voucher-type/{id}');

/*----------End Vouchers Management----------------*/
/*--------------Advertisement--------------*/
Route::get('/advertisement', 'Admin\AdvertisementController@getAllAdvertisement')->name('advertisement');
Route::post('/create-advertisement', 'Admin\AdvertisementController@CreateAdvertisement')->name('create-advertisement');
Route::get('edit-advertisement/{id}', 'Admin\AdvertisementController@editAdvertisementView')->name('edit-advertisement/{id}');
Route::post('edit-advertisement', 'Admin\AdvertisementController@putAdvertisement')->name('edit-advertisement');
Route::get('delete-advertisement/{id}', 'Admin\AdvertisementController@deleteAdvertiesementImg')->name('delete-advertisement/{id}');
Route::get('change-advertisement-status', 'Admin\AdvertisementController@changeAdvertiesementStatus');
/*----------Home Page-------------*/
/*-----Banner---------*/
Route::get('/banner', 'Admin\HomePageController@getAll')->name('banner');
Route::post('/add-banner', 'Admin\HomePageController@AddBanner')->name('add-banner');
Route::get('delete-banner/{id}', 'Admin\HomePageController@deleteBanner')->name('delete-banner/{id}');
Route::get('edit-banner/{id}', 'Admin\HomePageController@editBanner')->name('edit-banner/{id}');
Route::post('edit-banner', 'Admin\HomePageController@putBanner')->name('edit-banner');
Route::get('change-banner-status', 'Admin\HomePageController@changeBannerStatus');
/*-----Reports-------*/
Route::get('/abounded-cart-reports', function () {
  return view('admin.reports.abounded-carts');
})->name('abounded-cart');

Route::get('/conversions-reports', function () {
  return view('admin.reports.conversions');
})->name('conversions-reports');

Route::get('/customer-traffic-analytics', function () {
  return view('admin.reports.customer-traffic-analytics');
})->name('customer-traffic-analytics');

Route::get('/place-reports', function () {
  return view('admin.reports.places');
})->name('place-reports');

Route::get('/sales-reports', function () {
  return view('admin.reports.sales');
})->name('sales-reports');

Route::get('/supplier-statements', function () {
  return view('admin.reports.supplier-statements');
})->name('supplier-statements');

Route::get('/supplier-sales-reports', function () {
  return view('admin.reports.supplier-sales');
})->name('supplier-sales-reports');

Route::get('/voucher-reports', function () {
  return view('admin.reports.voucher');
})->name('voucher-reports');

Route::get('/vouchers-view-analytics', function () {
  return view('admin.reports.vouchers-view-analytics');
})->name('vouchers-view-analytics');

Route::get('/withdrawal-reports', function () {
  return view('admin.reports.withdrawals');
})->name('withdrawal-reports');

/*-----*/
Route::get('/destroy', 'Admin\ProductsController@destroy')->name('/destroy');







/*-----*/
});