 <!--Start footer-->
		<footer class="footer">
			<div class="container">
				<div class="text-center">
					 <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="#"> <?php echo e(env('APP_NAME')); ?></a>.</strong> All rights
				</div>
			</div>
		</footer><!--End footer--><?php /**PATH C:\xampp\htdocs\dashnox\resources\views/backend/include/footer.blade.php ENDPATH**/ ?>