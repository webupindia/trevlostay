<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Model\Products;

class Products extends Model
{
	 protected $table = 'products';

  
}
