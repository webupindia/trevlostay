<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Model\Products;
class Productimg extends Model
{
    protected $table = 'product_img';

     protected $fillable = ['product_id', 'product_img'];
     
     public function products(){
      return $this->hasOne('App\Model\Products','product_id','id');
    }
}
