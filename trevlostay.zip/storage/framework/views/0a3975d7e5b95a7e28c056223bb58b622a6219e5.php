    <link href="<?php echo e(asset('admin/plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/animate.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('admin/css/icons.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('admin/css/sidebar-menu.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/css/app-style.css')); ?>" rel="stylesheet"><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/backend/include/style.blade.php ENDPATH**/ ?>