@extends('admin.layouts.master')
@section('title', 'Add Combo Product')
@push('page-style')
<!--text editor-->
<link rel="stylesheet" href="{{asset('admin/plugins/summernote/dist/summernote-bs4.css')}}" />
  <!--multi select-->
  <link href="{{asset('admin/plugins/jquery-multi-select/multi-select.css')}}" rel="stylesheet" type="text/css">
   <!--Select Plugins-->
  <link href="{{asset('admin/plugins/select2/css/select2.min.css')}}" rel="stylesheet"/>
  <link href="{{asset('admin/plugins/bootstrap-datetimepicker/css/jquery.datetimepicker.css')}}" rel="stylesheet"/>

<style>

    .imgPreview2 img {
        padding: 8px;
        max-width: 100px;
    }

    .imgPreview3 img {
        padding: 8px;
        max-width: 100px;
    }

</style>
@endpush
@section('content')
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Add Combo Product</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Products Management</a></li>
                    <li class="breadcrumb-item"><a href="{{route('products')}}">Products</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add Combo Product</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="{{ route('add-combo-product') }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-address-book-o"></i>
                                Add New Combo Product
                            </h4>
                            <div class="row">
                               
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom01">Select Combo Product</label>
                                        <select name="name[]" class="form-control  multiple-select" multiple="multiple">
                                          @foreach($Products as $Product)
                                            <option value="{{ $Product->id }}" {{in_array($Product->id, old("name") ?: []) ? "selected": ""}}>{{ $Product->name }}</option>
                                            @endforeach

                                        </select>
                                        <span class="text-danger">{{ $errors->first('name') }}</span>
                                    </div>
                                </div>

                                <input type="hidden" name="type" value="Combo">

                                 <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="marketed">Reference Product</label>
                                        <select name="reference_product_id" class="form-control single-select">
                                            @foreach($Products as $Product)
                                            <option value="{{ $Product->id }}">{{ $Product->name }}</option>
                                            @endforeach
                                        </select>
                                        <span class="text-danger">{{ $errors->first('reference_product_id') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="validationCustom01">Slug</label>
                                        <input type="text" name="slug" class="form-control" placeholder="Enter Page Slug " value="{{old('slug')}}">
                                        <span class="text-danger">{{ $errors->first('slug') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="validationCustom01">Amount</label>
                                        <input type="text" name="sale_amount" class="form-control" placeholder="Enter Sale Amount " value="{{old('sale_amount')}}">
                                        <span class="text-danger">{{ $errors->first('sale_amount') }}</span>
                                    </div>
                                </div>
                                 <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="validationCustom01">Offer Amount</label>
                                        <input type="text" name="offer_amount" class="form-control" placeholder="Enter Offer Amount " value="{{old('offer_amount')}}">
                                        <span class="text-danger">{{ $errors->first('offer_amount') }}</span>
                                    </div>
                                </div>

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="">Availability </label><br>
                                        <div class="icheck-material-primary icheck-inline">
                                            <input type="radio" id="male" name="availability" value="1" checked />
                                            <label for="male">Yes</label>
                                        </div>
                                        <div class="icheck-material-primary icheck-inline">
                                            <input type="radio" id="female" name="availability" value="0" />
                                            <label for="female">No</label>
                                        </div>
                                        <span class="text-danger">{{ $errors->first('availability') }}</span>
                                    </div>
                                </div>
                        
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="marketed">Product Images</label>
                                        <div class="user-image mb-3 text-center">
                                            <div class="imgPreview2"> </div>
                                        </div>
                                        <div class="custom-file">
                                            <input type="file" name="product_img[]" class="custom-file-input" id="images2" multiple="multiple">
                                            <label class="custom-file-label" for="images">Choose Mulltiple Product image</label>
                                        </div>
                                        <span class="text-danger">{{ $errors->first('slider_img') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom4">Terms & Condition</label>
                                        <textarea rows="5" cols="5" name="term_condition" class="form-control">{{old('term_condition')}}</textarea>
                                        <span class="text-danger">{{ $errors->first('term_condition') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom4">Product Details</label>
                                        <textarea id="summernoteEditor" name="product_details" class="form-control">{{old('product_details')}}</textarea>
                                        <span class="text-danger">{{ $errors->first('product_details') }}</span>
                                    </div>
                                </div>


                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

@endsection
@push('page-script')
<!-- jQuery -->
<script src="{{asset('admin/plugins/summernote/dist/summernote-bs4.min.js')}}"></script>
<script>
    $('#summernoteEditor').summernote({
        height: 200,
        tabsize: 2
    });
</script>
<script>
    $(function() {
        // Multiple images preview with JavaScript
        var multiImgPreview = function(input, imgPreviewPlaceholder) {

            if (input.files) {
                var filesAmount = input.files.length;

                for (i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();

                    reader.onload = function(event) {
                        $($.parseHTML('<img>')).attr('src', event.target.result).appendTo(imgPreviewPlaceholder);
                    }

                    reader.readAsDataURL(input.files[i]);
                }
            }

        };

        $('#images2').on('change', function() {
            multiImgPreview(this, 'div.imgPreview2');
        });
        $('#images3').on('change', function() {
            multiImgPreview(this, 'div.imgPreview3');
        });
    });

</script>
 <script src="{{asset('admin/plugins/bootstrap-datetimepicker/js/jquery.datetimepicker.full.js')}}"></script>
  <!--Multi Select Js-->
    <script src="{{asset('admin/plugins/jquery-multi-select/jquery.multi-select.js')}}"></script>
    <script src="{{asset('admin/plugins/jquery-multi-select/jquery.quicksearch.js')}}"></script>

     <!--Select Plugins Js-->
    <script src="{{asset('admin/plugins/select2/js/select2.min.js')}}"></script>
        <script>
            /*jslint browser:true*/
            /*global jQuery, document*/

            jQuery(document).ready(function () {
                'use strict';

                jQuery('#filter-date, #search-from-date, #search-to-date').datetimepicker();
            });
        </script>
    
       <script>
        $(document).ready(function() {
            $('.single-select').select2();
      
            $('.multiple-select').select2();

        //multiselect start

            $('#my_multi_select1').multiSelect();
            $('#my_multi_select2').multiSelect({
                selectableOptgroup: true
            });

            $('#my_multi_select3').multiSelect({
                selectableHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                selectionHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                afterInit: function (ms) {
                    var that = this,
                        $selectableSearch = that.$selectableUl.prev(),
                        $selectionSearch = that.$selectionUl.prev(),
                        selectableSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selectable:not(.ms-selected)',
                        selectionSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selection.ms-selected';

                    that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
                        .on('keydown', function (e) {
                            if (e.which === 40) {
                                that.$selectableUl.focus();
                                return false;
                            }
                        });

                    that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                        .on('keydown', function (e) {
                            if (e.which == 40) {
                                that.$selectionUl.focus();
                                return false;
                            }
                        });
                },
                afterSelect: function () {
                    this.qs1.cache();
                    this.qs2.cache();
                },
                afterDeselect: function () {
                    this.qs1.cache();
                    this.qs2.cache();
                }
            });

         $('.custom-header').multiSelect({
              selectableHeader: "<div class='custom-header'>Selectable items</div>",
              selectionHeader: "<div class='custom-header'>Selection items</div>",
              selectableFooter: "<div class='custom-header'>Selectable footer</div>",
              selectionFooter: "<div class='custom-header'>Selection footer</div>"
            });


          });

    </script>
@endpush
