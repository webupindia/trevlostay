@extends('supplier.layouts.master')
@section('title', 'Products Rating Pages')
@push('page-style')
<!--Data Tables -->
<link href="{{asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
   <!--Switchery-->
  <link href="{{asset('admin/plugins/switchery/css/switchery.min.css')}}" rel="stylesheet" />
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" ></script>
  
  <link href="{{asset('admin/plugins/bootstrap-switch/bootstrap-switch.min.css')}}" rel="stylesheet">

@endpush
@section('content')
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Product Rating</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Products Management</a></li>
                     <li class="breadcrumb-item"><a href="{{route('supplier-products')}}">Product</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Product Rating</li>
                </ol>
            </div>
        
        </div>
        <!-- End Breadcrumb-->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> All Products Rating</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Product Name</th>
                                        <th>User Name</th>
                                        <th>Review</th>
                                    </tr>
                                </thead>
                                <tbody>
                          
                                @foreach($Rating as $Ratings)
                                
                                 <tr>
                                  
                                <td>{{ $loop->iteration }}</td>
                                  @if($Products->type == 'Combo')
                                <td>
                           
                                 @foreach (explode(',', $Products->name) as $productName)
                                   @foreach($Allproduct as $Allproducts)
                                     @if($productName == $Allproducts['id'])
                                          <div> <b>&#8680;</b> {{$Allproducts->name}}</div>
                                      @endif
                                  @endforeach
                                @endforeach
                                  </td>
                             @else
                                <td>{{$Products->name}}</td>
                             @endif
                                <td>{{ $Ratings->name}}</td>
                                <td>{{ $Ratings->star}}</td>
                
                                 </tr>
                                   @endforeach
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

@endsection
@push('page-script')
<!--Data Tables js-->
<script src="{{asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')}}"></script>
 <!--Switchery Js-->
    <script src="{{asset('admin/plugins/switchery/js/switchery.min.js')}}"></script>
    <script>
      var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
      $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());
       });
    </script>

    <!--Bootstrap Switch Buttons-->
    <script src="{{asset('assets/plugins/bootstrap-switch/bootstrap-switch.min.js')}}"></script>

<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();

    });

</script>
@endpush
