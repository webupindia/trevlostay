@extends('supplier.layouts.master')
@section('title', 'Products Pages')
@push('page-style')
<!--Data Tables -->
<link href="{{asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<style type="text/css">
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  min-width: 50px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 6px 2px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
.img-hover{
    cursor: pointer;
}

</style>
@endpush
@section('content')
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Products</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Products Management</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Products</li>
                </ol>
            </div>
            <div class="col-sm-3">
                <div class="btn-group float-sm-right">
                    <a href="{{route('supplier-add-product')}}" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i>Add New Products</a>
                </div>
            </div>
        </div>
        <!-- End Breadcrumb-->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> All Products</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable" class="table table-bordered">
                                 <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Product Images</th>
                                        <th>Product Name</th>
                                        <th>Category</th>
                                        <th>Sale Amount</th>
                                        <th>Offer Amount</th>
                                       
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($Products as $key=> $Product)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>
                                             @foreach($Productimage as $key2 => $Productimagess)
                                               @if($Productimagess->product_id == $Product['id'])
                                          <span class="dropdown">
                                               <img src="{{asset('images/products/'.$Productimagess->product_img )}}" class="img-hover" alt="" height="50px" width="50px">
                                        
                                           </span>
                                                @endif
                                                @endforeach
                                        </td>
                                          <td>{{ $Product->name}}</td>
                                         @foreach($Categories as $key5 => $Category)
                                        @if($Product->category_id == $Category['id'])
                                        <td>{{ $Category->category_name }}</td>
                                        @endif
                                        @endforeach
                                        <td><del>{{ $Product->sale_amount}}</del> &#36;</td>
                                        <td>{{ $Product->offer_amount}} &#36;</td>
                                     

                                        <td>
                                      <div class="dropdown">
                                     <a href="javascript:void();" class="dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown">
                                      <i class="icon-options"></i>
                                     </a>
                                      <div class="dropdown-menu dropdown-menu-right">
                                      <a class="dropdown-item" href="{{route('supplier-product-review/{id}',['id'=>Crypt::encrypt($Product->id)])}}" title="View Review">View Review </a>

                                      <a class="dropdown-item" href="{{route('supplier-product-rating/{id}',['id'=>Crypt::encrypt($Product->id)])}}" title="View Rating">View Rating</a>

                                      <a class="dropdown-item" href="{{route('supplier-edit-product/{id}',['id'=>Crypt::encrypt($Product->id)])}}" title="Edit Product">Edit Product</a>

                                      <a class="dropdown-item" href="{{route('supplier-delete-product/{id}',['id'=>Crypt::encrypt($Product->id)])}}" title="Delete Product">Delete Product</a>
                                     
                                       </div>
                                      </div>
                                           
                                        </td>

                                    </tr>
                                    @endforeach
                                </tbody>


                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

@endsection
@push('page-script')
<!--Data Tables js-->
<script src="{{asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')}}"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();

    });

</script>

@endpush
