
<select name="applicable_countries" class="form-control  multiple-select" multiple="multiple">
  
   <option value="Zimbabwe">Zimbabwe</option>
</select>
      <?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/include/country.blade.php ENDPATH**/ ?>