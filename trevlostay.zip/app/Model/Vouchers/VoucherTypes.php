<?php

namespace App\Model\Vouchers;

use Illuminate\Database\Eloquent\Model;

class VoucherTypes extends Model
{
   protected $table = 'voucher_types';
}
