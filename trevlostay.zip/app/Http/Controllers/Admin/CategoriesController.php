<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Categories;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;

class CategoriesController extends Controller
{
		public function getAllCategories()
    {
        $Categories = Categories::latest()->orderBy('id', 'desc')->get();
        if(count($Categories)>0){
            return view('admin.pages.categories.categories',['Categories'=>$Categories]);
        } else {
        	 connectify('error', 'Ooops 🙁', 'No Data Found ');
            return view('admin.pages.categories.categories',['Categories'=>$Categories]);
        }
    }
	public function CreateCategory(Request $request)
    {
    	 $this->validate($request, [

                'category_name'   => 'required|min:3|unique:categories',
                'slug'       => 'required|min:5|unique:categories',
                'thumbnail'  => 'required|mimes:jpeg,jpg,png|max:3072|dimensions:max_width=233,max_height=145',
                'banner'     => 'required|mimes:jpeg,jpg,png|max:5102|dimensions:max_width=1202,max_height=340',
              ]);

    	     if($request->hasFile('thumbnail')) {
               	$fileName = time().'.'.$request->thumbnail->extension();  
                  $request->thumbnail->move(public_path('images/category/thumbnail'), $fileName);
                 $thumbnail = $fileName;
            }

    	     if($request->hasFile('banner')) {
               	$fileName = time().'.'.$request->banner->extension();  
                  $request->banner->move(public_path('images/category/banner'), $fileName);
                 $banner = $fileName;
            }

	    	  $result = new Categories();

	        $result->category_name        = $request['category_name'];
	        $result->slug                 = $request['slug'];
	        $result->thumbnail            = $thumbnail;
	        $result->banner               = $banner;
	        if($result->save())
	        {
	            connectify('success', 'Haa Haa 😊 ', 'New Category  Created 😊 Successfully.');
	            return redirect()->route('categories')->with('success','😊 New Category Created  😊 Successfully 😊');
	        }
	        else
	        { 
	        	connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
	        	return redirect()->back()->with('error' ,'🙁 Something went wrong!!🙁 Please Try again 🙁');
	        }
    }
       public function editCategoryView($id)
    {

       try {
           $decrypted    = Crypt::decrypt($id);
           $getResult    = Categories::where('Id',$decrypted)->first();
           $getResults   = Categories::select('id')->latest()->get();

           if(!is_null($getResult)){
            return view('admin.pages.categories.edit-categories',['getResult'=>$getResult,'getResults'=>$getResults]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
     public function putCategory(Request $request)
    {
        $this->validate($request, [
            'category_name'       => 'required|min:2',
            'slug'             => 'required|min:5',
            'thumbnail'  => 'nullable|mimes:jpeg,jpg,png|max:3072|dimensions:max_width=233,max_height=145',
            'banner'     => 'nullable|mimes:jpeg,jpg,png|max:5102|dimensions:max_width=1202,max_height=340',
           
         ]);

        $id                = Crypt::decrypt($request['id']);
        $category_name     = strip_tags($request['category_name']);
        $slug              = strip_tags($request['slug']);

        $Categories = Categories::find($id);

     if($request->thumbnail != ''){        
          $path = public_path().'/images/category/thumbnail\\';

          //code for remove old file
          if($Categories->thumbnail != ''  && $Categories->thumbnail != null){
               $file_old = $path.$Categories->thumbnail;
               unlink($file_old);
          }
          //upload new file
          $file = $request->thumbnail;
          $filename =  time().'.'.$file->extension();
          $file->move($path, $filename);
          //for update in table
          $Categories->update(['thumbnail' => $filename]);
        }

      if($request->banner != ''){        
          $path = public_path().'/images/category/banner\\';

          //code for remove old file
          if($Categories->banner != ''  && $Categories->banner != null){
               $file_old = $path.$Categories->banner;
               unlink($file_old);
          }
          //upload new file
          $file = $request->banner;
          $filename =  time().'.'.$file->extension();
          $file->move($path, $filename);
          //for update in table
          $Categories->update(['banner' => $filename]);
        }

          Categories::where('id',$id)->update([
            'category_name'    => $category_name,
            'slug'             => $slug,
          
        ]);

        connectify('success', 'Haa Haa 😊 ', ' Category Updated 😊 Successfully.'); 
            return redirect()->route('categories')->with('success','Category Updated 😊 Successfully');
    }
      public function deleteCategory($id)
    {
        $id         =   Crypt::decrypt($id);
        $Categories =   Categories::findOrFail($id);
       
        $thumbnail_path = public_path("/images/category/thumbnail\\") .$Categories->thumbnail;
        $banner_path = public_path("/images/category/banner\\") .$Categories->banner;
        
            if(File::exists($thumbnail_path)) {
                File::delete($thumbnail_path);
            }
             if(File::exists($banner_path)) {
                File::delete($banner_path);
            }
             
          $Categories->delete();

        if($Categories){
             connectify('success', 'success ', '😪 ​​​​​ Category has been deleted Successfully.😪');
            return redirect()->back()->with('success',' Category has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
}
