
<?php $__env->startSection('title', 'Edit Combo Product '); ?>
<?php $__env->startPush('page-style'); ?>
<!--text editor-->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/summernote/dist/summernote-bs4.css')); ?>" />
  <!--multi select-->
  <link href="<?php echo e(asset('admin/plugins/jquery-multi-select/multi-select.css')); ?>" rel="stylesheet" type="text/css">
   <!--Select Plugins-->
  <link href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet"/>
  <link href="<?php echo e(asset('admin/plugins/bootstrap-datetimepicker/css/jquery.datetimepicker.css')); ?>" rel="stylesheet"/>

<style>
    .imgPreview img {
        padding: 8px;
        max-width: 100px;
    }
.dropdown{
   
 padding-left: 10px;

}
.dropdown-content{
    text-align: center;
}
.img-hover{
padding:10px; 
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Edit Combo Product </h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Product Management</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('products')); ?>">Product</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Combo Product </li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('supplier-edit-combo-product')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-edit"></i>
                               Edit Combo Product 
                            </h4>
                              <div class="row">
                                 <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom01">Select Combo Product</label>
                                        <select name="name[]" class="form-control  multiple-select" multiple="multiple">

                                        <?php $__currentLoopData = explode(',', $getResult->name); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Productname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AllProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($AllProduct->type == "Single"): ?>
                                        <option value="<?php echo e($AllProduct->id); ?>" <?php echo e($Productname == $AllProduct->id ? 'selected' : ''); ?> > <?php echo e($AllProduct->name); ?></option>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                          
                                        </select>
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                </div>
                                <input type="hidden" name="type" value="Combo">
                                
                                   <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="marketed">Reference Product</label>
                                        <select name="reference_product_id" class="form-control single-select">
                                            <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AllProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                             <?php if($AllProduct->type == "Single"): ?>
                                            <option value="<?php echo e($AllProduct->id); ?>" <?php echo e($getResult->reference_product_id == $AllProduct->id ? 'selected' : ''); ?>><?php echo e($AllProduct->name); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger"><?php echo e($errors->first('reference_product_id')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="validationCustom01">Slug</label>
                                        <input type="text" name="slug" class="form-control" placeholder="Enter Page Slug " value="<?php echo e($getResult->slug); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('slug')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="validationCustom01">Sale Amount</label>
                                        <input type="text" name="sale_amount" class="form-control" placeholder="Enter Sale Amount " value="<?php echo e($getResult->sale_amount); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('sale_amount')); ?></span>
                                    </div>
                                </div>
                                  <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="validationCustom01">Offer Amount</label>
                                        <input type="text" name="offer_amount" class="form-control" placeholder="Enter Offer Amount " value="<?php echo e($getResult->offer_amount); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('offer_amount')); ?></span>
                                    </div>
                                </div>
                                
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="">Availability </label><br>
                                        <div class="icheck-material-primary icheck-inline">
                                            <input type="radio" id="male" name="availability" value="1" checked />
                                            <label for="male">Yes</label>
                                        </div>
                                        <div class="icheck-material-primary icheck-inline">
                                            <input type="radio" id="female" name="availability" value="0" />
                                            <label for="female">No</label>
                                        </div>
                                        <span class="text-danger"><?php echo e($errors->first('availability')); ?></span>
                                    </div>
                                </div>
                                       <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="marketed">Product Images</label>
                                        <div class="user-image mb-3 text-center">
                                            <div class="imgPreview"> </div>
                                        </div>
                                        <div class="custom-file">
                                            <input type="file" name="product_img[]" class="custom-file-input" id="images" multiple="multiple">
                                            <label class="custom-file-label" for="images">Choose Mulltiple Product image</label>
                                        </div>
                                        <span class="text-danger"><?php echo e($errors->first('slider_img')); ?></span>
                                    </div>
                                </div>
                                 <?php $__currentLoopData = $Productimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $Productimagess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <?php if($Productimagess->product_id == $getResult->id): ?>
                                          <div class="dropdown">
                                               <img src="<?php echo e(asset('images/products/'.$Productimagess->product_img )); ?>" class="img-hover" alt="" height="50px" width="70px">
                                         <div class="dropdown-content">
                                               <a href="<?php echo e(route('delete-product-image/{id}',['id'=>Crypt::encrypt($Productimagess->id)])); ?>" title="Delete" class="btn btn-danger aDisplay"><i class="icon-trash "></i></a>
                                           </div> 
                                           </div>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom4">Terms & Condition</label>
                                        <textarea rows="5" cols="5" name="term_condition" class="form-control"><?php echo e($getResult->term_condition); ?></textarea>
                                        <span class="text-danger"><?php echo e($errors->first('term_condition')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom4">Product Details</label>
                                        <textarea id="summernoteEditor" name="product_details" class="form-control"><?php echo e($getResult->product_details); ?></textarea>
                                        <span class="text-danger"><?php echo e($errors->first('product_details')); ?></span>
                                    </div>
                                </div>
                                <input type="hidden" name="id" value="<?php echo e(Crypt::encrypt($getResult->id)); ?>">
                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>


<script>
    $(function() {
        // Multiple images preview with JavaScript
        var multiImgPreview = function(input, imgPreviewPlaceholder) {

            if (input.files) {
                var filesAmount = input.files.length;

                for (i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();

                    reader.onload = function(event) {
                        $($.parseHTML('<img>')).attr('src', event.target.result).appendTo(imgPreviewPlaceholder);
                    }

                    reader.readAsDataURL(input.files[i]);
                }
            }

        };

        $('#images').on('change', function() {
            multiImgPreview(this, 'div.imgPreview');
        });
    });

</script>
<script src="<?php echo e(asset('admin/plugins/summernote/dist/summernote-bs4.min.js')); ?>"></script>
<script>
    $('#summernoteEditor').summernote({
        height: 200,
        tabsize: 2
    });

</script>

</script>
 <script src="<?php echo e(asset('admin/plugins/bootstrap-datetimepicker/js/jquery.datetimepicker.full.js')); ?>"></script>
  <!--Multi Select Js-->
    <script src="<?php echo e(asset('admin/plugins/jquery-multi-select/jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/jquery-multi-select/jquery.quicksearch.js')); ?>"></script>

     <!--Select Plugins Js-->
    <script src="<?php echo e(asset('admin/plugins/select2/js/select2.min.js')); ?>"></script>
        <script>
            /*jslint browser:true*/
            /*global jQuery, document*/

            jQuery(document).ready(function () {
                'use strict';

                jQuery('#filter-date, #search-from-date, #search-to-date').datetimepicker();
            });
        </script>
    
       <script>
        $(document).ready(function() {
            $('.single-select').select2();
      
            $('.multiple-select').select2();

        //multiselect start

            $('#my_multi_select1').multiSelect();
            $('#my_multi_select2').multiSelect({
                selectableOptgroup: true
            });

            $('#my_multi_select3').multiSelect({
                selectableHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                selectionHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                afterInit: function (ms) {
                    var that = this,
                        $selectableSearch = that.$selectableUl.prev(),
                        $selectionSearch = that.$selectionUl.prev(),
                        selectableSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selectable:not(.ms-selected)',
                        selectionSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selection.ms-selected';

                    that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
                        .on('keydown', function (e) {
                            if (e.which === 40) {
                                that.$selectableUl.focus();
                                return false;
                            }
                        });

                    that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                        .on('keydown', function (e) {
                            if (e.which == 40) {
                                that.$selectionUl.focus();
                                return false;
                            }
                        });
                },
                afterSelect: function () {
                    this.qs1.cache();
                    this.qs2.cache();
                },
                afterDeselect: function () {
                    this.qs1.cache();
                    this.qs2.cache();
                }
            });

         $('.custom-header').multiSelect({
              selectableHeader: "<div class='custom-header'>Selectable items</div>",
              selectionHeader: "<div class='custom-header'>Selection items</div>",
              selectableFooter: "<div class='custom-header'>Selectable footer</div>",
              selectionFooter: "<div class='custom-header'>Selection footer</div>"
            });


          });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('supplier.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/supplier/pages/products/combo-product/edit-combo-product.blade.php ENDPATH**/ ?>