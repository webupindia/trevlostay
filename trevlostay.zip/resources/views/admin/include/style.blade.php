    <link href="{{asset('admin/plugins/simplebar/css/simplebar.css')}}" rel="stylesheet">
    <link href="{{asset('admin/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{asset('admin/css/animate.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('admin/css/icons.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('admin/css/sidebar-menu.css')}}" rel="stylesheet">
    <link href="{{asset('admin/css/app-style.css')}}" rel="stylesheet">