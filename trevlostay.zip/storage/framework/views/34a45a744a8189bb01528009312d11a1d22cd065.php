<html>
<head>
<title>Travelostay</title>
</head>	
<body>
<h1 style="margin-top:10%; text-align: center;">Welcome To Travelostay</h1>
<a href="<?php echo e(route('ts-admin')); ?>" style="border:none; width: 90px; text-decoration: none; background-color: green; padding: 10px 10px; color: white; display: block; margin:auto;" >Admin Login</a><br>
<a href="<?php echo e(route('supplier-login')); ?>" style="border:none; width: 110px; text-decoration: none; background-color: green; padding: 10px 10px; color: white; display: block; margin:auto;" >Supplier Login</a>


<p>Admin Login<br>
 <span>admin@gmail.com</span><br>
 <span>demo123@</span>
</p>
<p>Supplier Login<br>
 <span>supplier@gmail.com</span><br>
 <span>demo123@</span>
</p>

	</body>
</html><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/welcome.blade.php ENDPATH**/ ?>