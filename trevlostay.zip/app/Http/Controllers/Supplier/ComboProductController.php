<?php

namespace App\Http\Controllers\Supplier;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Products;
use App\Model\Categories;
use App\Model\Supplier;
use App\Model\Productimg;
use App\Model\Offerimg;
use App\Model\Reviews;
use App\Model\Rating;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

class ComboProductController extends Controller
{
     public function getAllComboProducts()
    {
         $Productimage  = Productimg::all();
         $SupplierName  = Supplier::all();
         $Allproduct  = Products::all();
         $supplier= Auth::guard('supplier')->user()->id;
        $Products = Products::latest()->where('supplier_id', $supplier)->get();
        $Products = Products::latest()
                   ->where('supplier_id', $supplier)
                   ->where('type','Combo')
                   ->orderBy('id', 'desc')->get();

        if(count($Products)>0){
            return view('supplier.pages.products.combo-product.combo-product',['Products'=> $Products,'Productimage'=> $Productimage,'SupplierName'=> $SupplierName,'Allproduct'=>$Allproduct]);
        } else {
        	 connectify('error', 'Ooops 🙁', 'No Data Found ');
            return view('supplier.pages.products.combo-product.combo-product',['Products'=> $Products,'Productimage'=> $Productimage,'SupplierName'=> $SupplierName]);
        }
    }
       public function add () {
        $categories = Categories::all();
        $Products = Products::latest()
                   ->where('type','Single')
                   ->where('supplier_id', '>',0)
                   ->orderBy('id', 'desc')->get();
        return view('supplier.pages.products.combo-product.add-combo-product', ['categories' => $categories,'Products'=>$Products]);
    }
    public function AddComboProduct(Request $request)
    {
    	 $this->validate($request, [
         
                'name'             => 'required',
                'reference_product_id' => 'required',
                'slug'             => 'required|min:5|unique:products',
                'sale_amount'      => 'required',
                'offer_amount'     => 'required',
                'type'             => 'required',
                'availability'     => 'required',
                'term_condition'   => 'required|min:5',
                'product_details'  => 'required|min:5',
                'product_img.*'     => 'mimes:jpeg,jpg,png|max:2048', 
              ]);
           
           if (Auth::guard('supplier')->user()) 
             {
               $status = 0;
               $supplier_id = Auth::guard('supplier')->user()->id;
             }else {
               $status = 1;
            
             }

	    	$result = new Products();
	      $result->category_id    = $request['0'];
        $result->supplier_id    = $supplier_id;
        $result->reference_product_id  = $request['reference_product_id'];
	      $result->name           = implode(',', $request['name']);
	      $result->slug           = $request['slug'];
	      $result->sale_amount    = $request['sale_amount'];
        $result->offer_amount   = $request['offer_amount'];
        $result->type           = $request['type'];
	      $result->availability   = $request['availability'];
        $result->status         = $status;
	      $result->term_condition       = $request['term_condition'];
	      $result->product_details      = $request['product_details'];

	        if($result->save())
	        {
               $images      =  array();
              if($files = $request->file('product_img'))
              {
                  foreach($files as $file) 
                  {
                     $productimgname     =   time().rand(1,100).'.'.$file->extension();
                     $destinationPath = public_path('images/products');

                      if($file->move($destinationPath, $productimgname))
                      {
                          $images[]   =   $productimgname;
                          $saveResult   =   Productimg::create([
                            'product_id' =>  $result->id,
                            'product_img' => $productimgname,
                          ]);   
                      }
                  }
              }
	            connectify('success', 'Haa Haa 😊 ', 'New combo Product  Added 😊 Successfully.');
	            return redirect()->route('supplier-combo-products')->with('success','😊 New combo Product   Added  Created  😊 Successfully 😊');
	        }
	        else
	        { 
	        	connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
	        	return redirect()->back()->with('error' ,'🙁 Something went wrong!!🙁 Please Try again 🙁');
	        }
    }
     public function editComboProductView($id)
    {

       try {
           $decrypted    = Crypt::decrypt($id);
           $getResult    = Products::where('Id',$decrypted)->first();
           $Productimage  = Productimg::all();
           $categories   = Categories::all();
           $Products     = Products::latest()
                          ->where('type','Single')
                          ->where('supplier_id', '>',0)
                          ->orderBy('id', 'desc')->get();
          

           if(!is_null($getResult)){
            return view('supplier.pages.products.combo-product.edit-combo-product',['getResult'=>$getResult,'Products'=>$Products,'categories' => $categories,'Productimage'=>$Productimage]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
     public function putComboProduct(Request $request)
    {
        $this->validate($request, [
                'reference_product_id' => 'required',
                'name'             => 'required',
                'slug'             => 'required',
                'sale_amount'      => 'required',
                'offer_amount'     => 'required',
                'type'             => 'required',
                'availability'    => 'required',
                'term_condition'  => 'required|min:5',
                'product_details' => 'required|min:5',
                'product_img.*'     => 'mimes:jpeg,jpg,png|max:2048',
         ]);
        $id                   = Crypt::decrypt($request['id']);
        $name                 = implode(',', $request['name']);
        $reference_product_id = strip_tags($request['reference_product_id']);
        $slug                 = strip_tags($request['slug']);
        $sale_amount          = strip_tags($request['sale_amount']);
        $offer_amount         = strip_tags($request['offer_amount']);
        $type                 = strip_tags($request['type']);
        $term_condition       = strip_tags($request['term_condition']);
        $availability         = strip_tags($request['availability']);
        $product_details      = $request['product_details'];

        $updatePage  = Products::where('id',$id)->update([
            
            'name'                  => $name,
            'reference_product_id'  => $reference_product_id,
            'sale_amount'           => $sale_amount,
            'offer_amount'          => $offer_amount,
            'type'                  => $type,
            'slug'                  => $slug,
            'availability'          => $availability,
            'term_condition'        => $term_condition,
            'product_details'       => $product_details,
            
        ]);

        if($updatePage){
           $images      =  array();
              if($files = $request->file('product_img'))
              {
                  foreach($files as $file) 
                  {
                     $productimgname     =   time().rand(1,100).'.'.$file->extension();
                     $destinationPath = public_path('images/products');

                      if($file->move($destinationPath, $productimgname))
                      {
                          $images[]   =   $productimgname;
                          $saveResult   =   Productimg::create([
                            'product_id' =>   $id,
                            'product_img' => $productimgname,
                          ]);   
                      }
                  }
              }
             connectify('success', 'Haa Haa 😊 ', 'Combo Product Updated 😊 Successfully.'); 
            return redirect()->route('supplier-combo-products')->with('success','Combo Product Updated 😊 Successfully');
        } else{
            connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
      public function deleteComboProduct($id)
    {
        $id         =   Crypt::decrypt($id);
        $Restricted =   Products::where('id',$id)->delete();

        if($Restricted){
             connectify('success', 'success ', '😪 ​​​​​ Product has been deleted Successfully.😪');
            return redirect()->back()->with('success',' Product has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }

}
