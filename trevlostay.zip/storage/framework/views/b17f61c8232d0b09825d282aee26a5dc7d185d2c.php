
<?php $__env->startSection('title', 'Advertisement Edit'); ?>
<?php $__env->startPush('page-style'); ?>
<!--text editor-->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/summernote/dist/summernote-bs4.css')); ?>" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Advertisement Edit</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Advertisement </a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('advertisement')); ?>">Advertisement</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Advertisement Edit</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                       <form action="<?php echo e(route('edit-advertisement')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="validationCustom01">Advertisement Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Enter Advertisement Name " value="<?php echo e($getResult->name); ?>">
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="validationCustom01">Type</label>
                                <select name="type" id="type" class="form-control" onchange="yesnoCheck(this);">

                                    <option value="">Choose Type</option>
                                    <option value="videos" <?php if($getResult->type =="videos" ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Videos</option>
                                    <option value="images" <?php if($getResult->type =="images" ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Images</option>

                                </select>
                                <span class="text-danger"><?php echo e($errors->first('type')); ?></span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group ">
                                <label for="validationCustom01">Images Or Videos</label>
                                <input type="file" name="ad_files" class="form-control" value="<?php echo e($getResult->ad_files); ?>" >
                                <span class="text-danger"><?php echo e($errors->first('ad_files')); ?></span>
                            </div>
                            <?php if($getResult->ad_files == 'images'): ?>
                             <img src="<?php echo e(asset('advertisement/'.$getResult->ad_files)); ?>" class="d-block m-auto" width="100px" height="50px"/>
                             <?php else: ?>
                              <video autoplay width="80" class="d-block m-auto">
                                    <source src="<?php echo e(asset('advertisement/'.$getResult->ad_files)); ?>" type="video/mp4">
                              </video>
                             <?php endif; ?>
                        </div>
                      

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputPassword" class="">Description</label>
                                <div class="position-relative">
                                    <textarea rows="4" class="form-control" name="description"><?php echo e($getResult->name); ?>

                                    </textarea>

                                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                                </div>
                                 <input type="hidden" name="id" value="<?php echo e(Crypt::encrypt($getResult->id)); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-footer">
                        <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                    </div>
                </form>

                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
<script src="<?php echo e(asset('admin/plugins/summernote/dist/summernote-bs4.min.js')); ?>"></script>
<script>
    $('#summernoteEditor').summernote({
        height: 400,
        tabsize: 2
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/pages/advertisement/edit-advertisement.blade.php ENDPATH**/ ?>