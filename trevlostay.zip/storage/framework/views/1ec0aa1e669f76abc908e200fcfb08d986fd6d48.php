
<?php $__env->startSection('title', 'Product Rating Edit'); ?>
<?php $__env->startPush('page-style'); ?>
<!--text editor-->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/summernote/dist/summernote-bs4.css')); ?>" />

<!-- Dropzone css -->
<link href="<?php echo e(asset('admin/plugins/dropzone/css/dropzone.css')); ?>" rel="stylesheet" type="text/css">
<style>
    .imgPreview img {
        padding: 8px;
        max-width: 100px;
    }

</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Product Rating Edit</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Products Management</a></li>
                     <li class="breadcrumb-item"><a href="<?php echo e(route('products')); ?>">Product</a></li>
              
                    <li class="breadcrumb-item active" aria-current="page">Product Rating Edit</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('edit-product-rating')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-edit"></i>
                                Product Rating Edit
                            </h4>
                            <div class="row">
                                  <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Rating Star</label>
                                        <input type="text" name="star" class="form-control" value="<?php echo e($Rating->star); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('star')); ?></span>
                                   
                                 </div>
                                 </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Status</label>
                                     
                                       <input type="hidden" name="status" value="0">
                                       <input type="checkbox" class="form-control" name="status" value="1" <?php echo e($Rating->status ? 'checked' : ''); ?>>


                                        <span class="text-danger"><?php echo e($errors->first('status')); ?></span>
                                   
                                 </div>
                                 </div>
                               
                                <input type="hidden" name="id" value="<?php echo e(Crypt::encrypt($Rating->id)); ?>">
                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>


<script>
    $(function() {
        // Multiple images preview with JavaScript
        var multiImgPreview = function(input, imgPreviewPlaceholder) {

            if (input.files) {
                var filesAmount = input.files.length;

                for (i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();

                    reader.onload = function(event) {
                        $($.parseHTML('<img>')).attr('src', event.target.result).appendTo(imgPreviewPlaceholder);
                    }

                    reader.readAsDataURL(input.files[i]);
                }
            }

        };

        $('#images').on('change', function() {
            multiImgPreview(this, 'div.imgPreview');
        });
    });

</script>
<script src="<?php echo e(asset('admin/plugins/summernote/dist/summernote-bs4.min.js')); ?>"></script>
<script>
    $('#summernoteEditor').summernote({
        height: 400,
        tabsize: 2
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/pages/products/rating/edit-rating.blade.php ENDPATH**/ ?>