@extends('supplier.layouts.master')
@section('title', 'Vouchers Pages')
@push('page-style')
<!--Data Tables -->
<link href="{{asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">



<style type="text/css">
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  min-width: 50px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 6px 2px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
.img-hover{
    cursor: pointer;
}
</style>
@endpush
@section('content')
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Vouchers</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Vouchers Management</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Vouchers</li>
                </ol>
            </div>
            <div class="col-sm-3">
                <div class="btn-group float-sm-right">
               
                     <a href="{{route('supplier-create-voucher')}}" class="btn btn-light waves-effect waves-light">Create Voucher</a>

                  
                </div>
            </div>
        </div>
        <!-- End Breadcrumb-->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> All Vouchers</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Banner</th>
                                        <th>Name</th>
                                        <th>Code</th>
                                        <th>Price</th>
                                        <th>Discount Value</th>
                                        <th>Currency</th>
                                       
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   @foreach($Vouchers as $Voucher)
                                      <tr>
                                          <td>{{ $loop->iteration }}</td>
                                          <td>
                                            <a target="blank" href="{{url('/images/vouchers')}}/{{$Voucher->images}}"><img src="{{asset('images/vouchers/'.$Voucher->images)}}" width="100px" height="50px" /></a>

                                          </td>
                                          <td>{{ $Voucher->name }}</td>
                                          <td>{{ $Voucher->code }}</td>
                                          <td>{{ $Voucher->price }}</td>
                                          <td>{{ $Voucher->discount_value }}</td>
                                          <td>{{ $Voucher->currency }}</td>
                                      
                                          </td>
                                           <td>
                                          <a href="{{route('supplier-edit-voucher/{id}',['id'=>Crypt::encrypt($Voucher->id)])}}" title="Edit" class="btn btn-success"><i class="icon-pencil"></i></a>

                                          <a href="{{route('supplier-delete-voucher/{id}',['id'=>Crypt::encrypt($Voucher->id)])}}"  title="Delete" class="btn btn-danger"><i class="icon-trash"></i></a>
                                        </td>
                                         
                                      </tr>
                                     @endforeach

                                   </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

@endsection
@push('page-script')
<!--Data Tables js-->
<script src="{{asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')}}"></script>
 <!--Switchery Js-->
    <script src="{{asset('admin/plugins/switchery/js/switchery.min.js')}}"></script>
    <script>
      var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
      $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());
       });
    </script>

   

<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();

    });

</script>
@endpush
