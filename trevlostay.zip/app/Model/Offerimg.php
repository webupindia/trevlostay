<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Model\Products;
class Offerimg extends Model
{
      protected $table = 'offer_img';

     protected $fillable = ['product_id', 'offer_img'];
     
     public function products(){
      return $this->hasOne('App\Model\Products','product_id','id');
    }
}
