<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
    <meta content="" name="description">
    <meta content="" name="author">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(env('APP_NAME')); ?></title>
    <link href="<?php echo e(asset('storage/logo/favicon.png')); ?>" rel="icon" type="image/x-icon">
    <?php echo $__env->make('backend.include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('page-style'); ?>
    <?php echo notifyCss(); ?>
</head>
 <?php
        $theme_names=DB::table('setting')->select('theme_name')->get();
    ?>         
       <?php $__currentLoopData = $theme_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<body class="bg-theme <?php echo e($theme_name->theme_name); ?>" >
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo $__env->make('notify::messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ============================================== -->
<!--Start wrapper-->
<div id="wrapper">
 
    <!-- sidebar-wrapper-->
    <?php echo $__env->make('backend.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- topbar header-->
    <?php echo $__env->make('backend.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- content-wrapper-->
    <?php echo $__env->yieldContent('content'); ?>
    <!--Start Back To Top Button-->
    <a class="back-to-top" href="javaScript:void();"><i class="fa fa-angle-double-up"></i></a>
    <!--End Back To Top Button-->
    <!-- topbar header-->
    <?php echo $__env->make('backend.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><!--End wrapper-->
<!-- ================JS All File==================== -->
   <?php echo $__env->make('backend.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('page-script'); ?>
  <?php echo $__env->make('backend.include.full-screen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    <?php echo notifyJs(); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\dashnox\resources\views/backend/layouts/master.blade.php ENDPATH**/ ?>