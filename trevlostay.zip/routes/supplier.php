<?php

use Illuminate\Support\Facades\Route;
/*----------Supplier----------------*/
Route::get('/supplier-signup', function () {
    return view('supplier.auth.signup');
})->name('supplier-signup');

Route::post('signup',[
  'uses' => 'Supplier\SupplierController@Singnup',
  'as'    =>'signup'
]);

Route::get('/supplier-login', 'Supplier\SupplierController@checkLogin')->name('supplier-login');

Route::post('/supplier-login',[
  'uses' => 'Supplier\SupplierController@postLogin',
  'as'    =>'supplier-login'
]);     

Route::get('/supplier-profile', function () {
  return view('supplier.auth.user-profile');
})->name('supplier-profile');

Route::post('/supplier-change-profile',[
  'uses' => 'Supplier\SupplierController@changeProfile',
  'as'    =>'supplier-change-profile'
]);  

Route::post('/supplier-changePassword',[
  'uses' => 'Supplier\SupplierController@changePassword',
  'as'    =>'supplier-changePassword'
]); 

// Password reset routes...
Route::get('/supplier-forget-password', function () {
  return view('supplier.auth.forget-password');
})->name('supplier-forget-password');

Route::post('supplier-forget-password',[
  'uses' => 'supplier\SupplierController@forget',
  'as'    =>'supplier-forget-password'
]);
Route::get('/reset/{token}', 'Supplier\SupplierController@reset')->name('password.reset');
Route::post('/reset/{token}', 'Supplier\SupplierController@reset')->name('reset');

Route::group(['middleware' => ['supplier'],'prefix'=>'supplier'], function () { 
Route::get('/supplier-dashboard', 'Supplier\SupplierController@Index')
       ->name('supplier-dashboard');
Route::get('/supplier-logout', 'Supplier\SupplierController@getLogout')
       ->name('supplier-logout');
/*===========Supplier Pages=================*/
/*-----Product Management-------*/
Route::get('/products', 'Supplier\ProductsController@getAllProducts')->name('supplier-products');
Route::get('/add-product', 'Supplier\ProductsController@add')->name('supplier-add-product');

Route::post('add-product', 'Supplier\ProductsController@AddProduct')
           ->name('supplier-add-product');

Route::get('edit-product/{id}', 'Supplier\ProductsController@editProductView')
          ->name('supplier-edit-product/{id}');

Route::post('edit-product', 'Supplier\ProductsController@putProduct')
          ->name('supplier-edit-product');

Route::get('delete-product/{id}', 'Supplier\ProductsController@deleteProduct')
          ->name('supplier-delete-product/{id}');

Route::get('delete-product-image/{id}', 'Supplier\ProductsController@deleteProductImg')->name('supplier-delete-product-image/{id}');          
/*------------End Page---------*/
/*-------------Product Review----------------*/
Route::get('product-review/{id}', 'Supplier\ProductsController@ProductReviews')->name('supplier-product-review/{id}');
/*-------------Product Rating----------------*/
Route::get('product-rating/{id}', 'Supplier\ProductsController@ProductRatings')->name('supplier-product-rating/{id}');
/*---------------Combo Product------------------*/
Route::get('/combo-products', 'Supplier\ComboProductController@getAllComboProducts')->name('supplier-combo-products');
Route::get('/add-combo-product', 'Supplier\ComboProductController@add')->name('supplier-add-combo-product');
Route::post('add-combo-product', 'Supplier\ComboProductController@AddComboProduct')->name('supplier-add-combo-product');
Route::get('edit-combo-product/{id}', 'Supplier\ComboProductController@editComboProductView')->name('supplier-edit-combo-product/{id}');
Route::post('edit-combo-product', 'Supplier\ComboProductController@putComboProduct')->name('supplier-edit-combo-product');
Route::get('delete-combo-product/{id}', 'Supplier\ComboProductController@deleteComboProduct')->name('supplier-delete-combo-product/{id}');
/*------------End Page---------*/
/*----------Vouchers Management----------------*/
Route::get('/vouchers', 'Supplier\VouchersController@getAllVouchers')->name('supplier-vouchers');
Route::get('/create-voucher', 'Supplier\VouchersController@getCategoryTypeId')->name('supplier-create-voucher');
Route::post('/create-voucher', 'Supplier\VouchersController@CreateVoucher')->name('supplier-create-voucher');
Route::get('/edit-voucher/{id}', 'Supplier\VouchersController@editVoucherView')->name('supplier-edit-voucher/{id}');
Route::post('/edit-voucher', 'Supplier\VouchersController@putVoucher')->name('supplier-edit-voucher');
Route::get('delete-voucher/{id}', 'Supplier\VouchersController@deleteVoucher')->name('supplier-delete-voucher/{id}');
/*--------------Advertisement--------------*/
Route::get('/advertisement', 'Supplier\AdvertisementController@getAllAdvertisement')->name('supplier-advertisement');
Route::post('/create-advertisement', 'Supplier\AdvertisementController@CreateAdvertisement')->name('supplier-create-advertisement');
Route::get('edit-advertisement/{id}', 'Supplier\AdvertisementController@editAdvertisementView')->name('supplier-edit-advertisement/{id}');
Route::post('edit-advertisement', 'Supplier\AdvertisementController@putAdvertisement')->name('supplier-edit-advertisement');
Route::get('delete-advertisement/{id}', 'Supplier\AdvertisementController@deleteAdvertiesementImg')->name('supplier-delete-advertisement/{id}');
/*-------------End Supplier Pages---------------*/
/*----------Home Page-------------*/
/*-----Banner---------*/
Route::get('/banner', 'Supplier\HomePageController@getAll')->name('supplier-banner');
Route::post('/add-banner', 'Supplier\HomePageController@AddBanner')->name('supplier-add-banner');
Route::get('delete-banner/{id}', 'Supplier\HomePageController@deleteBanner')->name('supplier-delete-banner/{id}');
Route::get('edit-banner/{id}', 'Supplier\HomePageController@editBanner')->name('supplier-edit-banner/{id}');
Route::post('edit-banner', 'Supplier\HomePageController@putBanner')->name('supplier-edit-banner');
Route::get('change-banner-status', 'Supplier\HomePageController@changeBannerStatus');
/*-----Reports-------*/

Route::get('/abounded-cart-reports', function () {
  return view('supplier.reports.abounded-carts');
})->name('supplier-abounded-cart');

Route::get('/conversions-reports', function () {
  return view('supplier.reports.conversions');
})->name('supplier-conversions-reports');

Route::get('/customer-traffic-analytics', function () {
  return view('supplier.reports.customer-traffic-analytics');
})->name('supplier-customer-traffic-analytics');

Route::get('/place-reports', function () {
  return view('supplier.reports.places');
})->name('supplier-place-reports');

Route::get('/sales-reports', function () {
  return view('supplier.reports.sales');
})->name('supplier-sales-reports');

Route::get('/supplier-statements', function () {
  return view('supplier.reports.supplier-statements');
})->name('supplier-supplier-statements');

Route::get('/supplier-sales-reports', function () {
  return view('supplier.reports.supplier-sales');
})->name('supplier-supplier-sales-reports');

Route::get('/voucher-reports', function () {
  return view('supplier.reports.voucher');
})->name('supplier-voucher-reports');

Route::get('/vouchers-view-analytics', function () {
  return view('supplier.reports.vouchers-view-analytics');
})->name('supplier-vouchers-view-analytics');

Route::get('/withdrawal-reports', function () {
  return view('supplier.reports.withdrawals');
})->name('supplier-withdrawal-reports');
 });


