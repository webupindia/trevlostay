
<?php $__env->startSection('title', 'Sales Reports'); ?>
<?php $__env->startPush('page-style'); ?>
 <!--Data Tables -->

  <link href="<?php echo e(asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('admin/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">

  <!--Bootstrap Datepicker-->
  <link href="<?php echo e(asset('admin/plugins/bootstrap-datepicker/css/bootstrap-datepicker.min.css')); ?>" rel="stylesheet" type="text/css">


  <?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>
  <div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumb-->
     <div class="row pt-2 pb-2">
        <div class="col-sm-9">
        <h4 class="page-title">Sales Reports</h4>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javaScript:void();"> Reports</a></li>
            <li class="breadcrumb-item active" aria-current="page">Sales Reports </li>
         </ol>
     </div>
     </div>
     <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header text-uppercase">Filter</div>
             <div class="card-body">
               <form>
                <div id="dateragne-picker">
                 <div class="input-daterange input-group">
                  <div class="input-group-prepend">
                   <span class="input-group-text">From</span>
                  </div>
                  <input type="text" class="form-control" name="start"/>
                  <div class="input-group-prepend">
                   <span class="input-group-text">to</span>
                  </div>
                  <input type="text" class="form-control" name="end"/>
                  <input type="submit" class="btn btn-success" value="Search">
                 </div>
               </div>
               </form>
            </div>
          </div>
        </div>
      </div><!--End Row-->
    <!-- End Breadcrumb-->
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Sales Reports Data</div>
            <div class="card-body">
              <div class="table-responsive">
              <table id="example" class="table table-bordered">
                  <thead>
                    <tr>
                        <th>Sr. No.</th>
                        <th>Field 1</th>
                        <th>Field 2</th>
                        <th>Field 3</th>
                        <th>Field 4</th>
                        <th>Datetime</th>
                        <th>Action</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <tr>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                      <td></td>
                    </tr>
                  
                </tbody>
            </table>
            </div>
            </div>
          </div>
        </div>
      </div><!-- End Row-->
<!--start overlay-->
    <div class="overlay toggle-menu"></div>
  <!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
        <!--Data Tables js-->
  <script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/jszip.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/pdfmake.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/vfs_fonts.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/buttons.html5.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/buttons.print.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/buttons.colVis.min.js')); ?>"></script>
  <!--Bootstrap Datepicker Js-->
    <script src="<?php echo e(asset('admin/plugins/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
    <script>
      $('#default-datepicker').datepicker({
        todayHighlight: true
      });
      $('#autoclose-datepicker').datepicker({
        autoclose: true,
        todayHighlight: true
      });

      $('#inline-datepicker').datepicker({
         todayHighlight: true
      });

      $('#dateragne-picker .input-daterange').datepicker({
       });

    </script>


    <script>
     $(document).ready(function() {
      //Default data table
       $('#default-datatable').DataTable();


       var table = $('#example').DataTable( {
        lengthChange: false,
        buttons: [ 'copy', 'excel', 'pdf', 'print', 'colvis' ]
      } );
 
     table.buttons().container()
        .appendTo( '#example_wrapper .col-md-6:eq(0)' );
      
      } );

    </script>


<?php $__env->stopPush(); ?>

<?php echo $__env->make('supplier.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/supplier/reports/sales.blade.php ENDPATH**/ ?>