<?php

namespace App\Model\Vouchers;

use Illuminate\Database\Eloquent\Model;

class VoucherCategories extends Model
{
   protected $table = 'voucher_categories';

    protected $fillable = ['category_name'];
}
