<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(env('APP_NAME')); ?></title>
  <!-- loader-->
  <link rel="icon" href="<?php echo e(asset('storage/logo/favicon.png')); ?>" type="image/x-icon">
  <link href="<?php echo e(asset('admin/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
  <link href="<?php echo e(asset('admin/css/animate.css')); ?>" rel="stylesheet" type="text/css"/>
  <link href="<?php echo e(asset('admin/css/icons.css')); ?>" rel="stylesheet" type="text/css"/>
  <link href="<?php echo e(asset('admin/css/app-style.css')); ?>" rel="stylesheet"/>
  <?php echo notifyCss(); ?>
</head>
 <?php
        $theme_names=DB::table('setting')->select('theme_name')->get();
    ?>         
       <?php $__currentLoopData = $theme_names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<body class="bg-theme <?php echo e($theme_name->theme_name); ?>" >
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   <?php echo $__env->make('notify::messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Start wrapper-->
 <div id="wrapper">
    <?php echo $__env->yieldContent('content'); ?>
    
  </div>
  <!--End wrapper-->
  <script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/sidebar-menu.js')); ?>"></script>
  <script src="<?php echo e(asset('admin/js/app-script.js')); ?>"></script>
  <?php echo notifyJs(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/layouts/login_master.blade.php ENDPATH**/ ?>