<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVouchersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('vouchers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('category_id');
            $table->unsignedBigInteger('types_id');
            $table->boolean('supplier_id')->nullable()->default(0);
            $table->string('name');
            $table->string('code');
            $table->string('applicable_countries');
            $table->double('price');
            $table->string('discount_value');
            $table->text('details');
            $table->boolean('status')->nullable()->default(0);
            $table->string('currency');
            $table->text('term_condition');
            $table->string('expiry_date_from');
            $table->string('expiry_date_to');
            $table->text('voucher_qty');
            $table->text('images');
            $table->timestamps();

            $table->foreign('category_id')->references('id')->on('voucher_categories')->onDelete('cascade');
            $table->foreign('types_id')->references('id')->on('voucher_types')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('vouchers');
    }
}
