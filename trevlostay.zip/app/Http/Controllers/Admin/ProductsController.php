<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Products;
use App\Model\Categories;
use App\Model\Supplier;
use App\Model\Productimg;
use App\Model\Offerimg;
use App\Model\Reviews;
use App\Model\Rating;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;

class ProductsController extends Controller
{
    public function getAllProducts()
    {
         $Offerimage    = Offerimg::all();
         $Productimage  = Productimg::all();
         $Categories    = Categories::all();
         $SupplierName  = Supplier::all();
         $Products = Products::latest()
                   ->where('type','Single')
                   ->orderBy('id', 'desc')->get();

        if(count($Products)>0){
            return view('admin.pages.products.products',['Products'=> $Products,'Productimage'=> $Productimage,'SupplierName'=> $SupplierName,'Offerimage'=> $Offerimage,'Categories'=>$Categories]);
        } else {
        	 connectify('error', 'Ooops 🙁', 'No Data Found ');
            return view('admin.pages.products.products',['Products'=> $Products,'Productimage'=> $Productimage,'SupplierName'=> $SupplierName,'Offerimage'=> $Offerimage,'Categories'=>$Categories]);
        }
    }
       public function add () {
        $categories = Categories::all();
        return view('admin.pages.products.add-product', ['categories' => $categories]);
    }


	public function AddProduct(Request $request)
    {
    	 $this->validate($request, [

                'category_id'      => 'required',
                'name'             => 'required|min:3|unique:products',
                'slug'             => 'required|min:5|unique:products',
                'sale_amount'      => 'required|numeric',
                'offer_amount'     => 'required|numeric',
                'type'             => 'required',
                'availability'     => 'required',
                'term_condition'   => 'required|min:5',
                'product_details'  => 'required|min:5',
                'product_img.*'     => 'mimes:jpeg,jpg,png|max:2048', 
              ]);
           
           if (Auth::guard('supplier')->user()) 
             {
               $status = 0;
               $supplier_id = Auth::guard('supplier')->user()->id;
             }else {
               $status = 1;
            
             }

        $supplier_id = $request->id;
	    	$result = new Products();
	        $result->category_id    = $request['category_id'];
          $result->supplier_id    = $supplier_id;
	        $result->name           = $request['name'];
	        $result->slug           = $request['slug'];
	        $result->sale_amount    = $request['sale_amount'];
          $result->offer_amount   = $request['offer_amount'];
          $result->type           = $request['type'];
	        $result->availability   = $request['availability'];
          $result->status         = $status;
	        $result->term_condition       = $request['term_condition'];
	        $result->product_details      = $request['product_details'];

	        if($result->save())
	        {
               $images      =  array();
              if($files = $request->file('product_img'))
              {
                  foreach($files as $file) 
                  {
                     $productimgname     =   time().rand(1,100).'.'.$file->extension();
                     $destinationPath = public_path('images/products');

                      if($file->move($destinationPath, $productimgname))
                      {
                          $images[]   =   $productimgname;
                          $saveResult   =   Productimg::create([
                            'product_id' =>  $result->id,
                            'product_img' => $productimgname,
                          ]);   
                      }
                  }
              }
	            connectify('success', 'Haa Haa 😊 ', 'New Product  Added 😊 Successfully.');
	            return redirect()->route('products')->with('success','😊 New Product  Added  Created  😊 Successfully 😊');
	        }
	        else
	        { 
	        	connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
	        	return redirect()->back()->with('error' ,'🙁 Something went wrong!!🙁 Please Try again 🙁');
	        }
       
    }
       public function editProductView($id)
    {

       try {
           $decrypted    = Crypt::decrypt($id);
           $getResult    = Products::where('Id',$decrypted)->first();
           $getResults   = Products::select('id')->latest()->get();
           $categories   = Categories::all();
          $Productimage  = Productimg::all();

           if(!is_null($getResult)){
            return view('admin.pages.products.edit-product',['getResult'=>$getResult,'getResults'=>$getResults,'categories' => $categories,'Productimage'=>$Productimage]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
     public function putProduct(Request $request)
    {
        $this->validate($request, [
                'category_id'      => 'required',
                'name'             => 'required|min:3',
                'slug'             => 'required|min:5',
                'sale_amount'      => 'required',
                'offer_amount'     => 'required',
                'type'             => 'required',
                'availability'     => 'required',
                'term_condition'   => 'required|min:5',
                'product_details'  => 'required|min:5',
                'product_img.*'    => 'mimes:jpeg,jpg,png|max:2048', 
         ]);
        $id                = Crypt::decrypt($request['id']);
        $category_id       = strip_tags($request['category_id']);
        $name              = strip_tags($request['name']);
        $slug              = strip_tags($request['slug']);
        $sale_amount       = strip_tags($request['sale_amount']);
        $offer_amount      = strip_tags($request['offer_amount']);
        $type              = strip_tags($request['type']);
        $term_condition    = strip_tags($request['term_condition']);
        $availability    = strip_tags($request['availability']);
        $product_details   = $request['product_details'];

        $updatePage  = Products::where('id',$id)->update([
            'category_id'     => $category_id,
            'name'            => $name,
            'sale_amount'     => $sale_amount,
            'offer_amount'    => $offer_amount,
            'type'            => $type,
            'slug'            => $slug,
            'availability'    => $availability,
            'term_condition'   => $term_condition,
            'product_details'  => $product_details,
        ]);

        if($updatePage){
           $images      =  array();
              if($files = $request->file('product_img'))
              {
                  foreach($files as $file) 
                  {
                     $productimgname     =   time().rand(1,100).'.'.$file->extension();
                     $destinationPath = public_path('images/products');

                      if($file->move($destinationPath, $productimgname))
                      {
                          $images[]   =   $productimgname;
                          $saveResult   =   Productimg::create([
                            'product_id' =>   $id,
                            'product_img' => $productimgname,
                          ]);   
                      }
                  }
              }
             connectify('success', 'Haa Haa 😊 ', ' Product Updated 😊 Successfully.'); 
            return redirect()->route('products')->with('success','Product Updated 😊 Successfully');
        } else{
            connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
      public function deleteProduct($id)
    {
        $id         =   Crypt::decrypt($id);
        $Restricted =   Products::where('id',$id)->delete();


        if($Restricted){
             connectify('success', 'success ', '😪 ​​​​​ Product has been deleted Successfully.😪');
            return redirect()->back()->with('success',' Product has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
     public function deleteProductImg($id)
    {
            $id          =   Crypt::decrypt($id);
            $Restricted  = Productimg::findOrFail($id);
            $image_path  = public_path("\images\products\\") .$Restricted->product_img;
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
            else{
                $Restricted->delete();
            }
            $Restricted->delete();
        if($Restricted){
             connectify('success', 'success ', '😪 ​​​​​ Product Image has been deleted Successfully.😪');
            return redirect()->back()->with('success','  Product Image has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }

     public function changeProductStatus(Request $request)
    {
        $user = Products::find($request->user_id);
        $user->status = $request->status;
       $user->save();
        smilify('success', 'Status successfully Update');
       return response()->json(['success' => 'Status successfully Update']);

    }
        /*---------Reviews---------*/
     public function ProductReviews($id)
    {
       try {
           $decrypted   = Crypt::decrypt($id);
           $Products    = Products::where('id',$decrypted)->first();
           $Reviews = DB::table('reviews')
             ->join('users', 'reviews.user_id', '=', 'users.id')
             ->select('reviews.*', 'users.name')
             ->where('product_id', $decrypted)
             ->get();
            $Allproduct  = Products::all();
         
           if(!is_null($Reviews)){
            return view('admin.pages.products.reviews.reviews',['Reviews'=>$Reviews,'Products'=>$Products,'Allproduct'=>$Allproduct]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
       public function EditReviews($id)
    {
       try {
            $decrypted   = Crypt::decrypt($id);
            $Reviews    = Reviews::where('id',$decrypted)->first();
      
           if(!is_null($Reviews)){
            return view('admin.pages.products.reviews.edit-review',['Reviews'=>$Reviews]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
      public function putProductReview(Request $request)
    {
        $this->validate($request, [
                'comment'      => 'required',
         ]);
        $id        = Crypt::decrypt($request['id']);
        $comment   = $request['comment'];
         $status   = $request['status'];

       $updatePage  = Reviews::where('id',$id)->update([
            'comment'  => $comment,
            'status'  => $status,
        ]);

        if($updatePage){
             connectify('success', 'Haa Haa 😊 ', 'Product Review Updated 😊 Successfully.'); 
            return redirect()->back()->with('success','Product Review Updated 😊 Successfully');
        } else{
            connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
          public function deleteProductReview($id)
    {
        $id         =   Crypt::decrypt($id);
        $Restricted =   Reviews::where('id',$id)->delete();

        if($Restricted){
             connectify('success', 'success ', '😪 ​​​​​ Product Review has been deleted Successfully.😪');
            return redirect()->back()->with('success',' Product Review has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
        /*---------Ratings---------*/
            public function ProductRatings($id)
    {
       try {
            $decrypted   = Crypt::decrypt($id);
            $Products    = Products::where('id',$decrypted)->first();
            $Rating = DB::table('rating')
             ->join('users', 'rating.user_id', '=', 'users.id')
             ->select('rating.*', 'users.name')
             ->where('product_id', $decrypted)
             ->get();
           $Allproduct  = Products::all();
         
           if(!is_null($Rating)){
            return view('admin.pages.products.rating.rating',['Rating'=>$Rating,'Products'=>$Products,'Allproduct'=>$Allproduct]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
       public function EditRatings($id)
    {
       try {
            $decrypted   = Crypt::decrypt($id);
            $Rating    = Rating::where('id',$decrypted)->first();
      
           if(!is_null($Rating)){
            return view('admin.pages.products.rating.edit-rating',['Rating'=>$Rating]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
      public function putProductRatings(Request $request)
    {
        $this->validate($request, [
                'star'      => 'required',
         ]);
    

        $id        = Crypt::decrypt($request['id']);
        $star     = $request['star'];
        $status   = $request['status'];

       $updatePage  = Rating::where('id',$id)->update([
            'star'  => $star,
            'status'  => $status,
        ]);

        if($updatePage){
             connectify('success', 'Haa Haa 😊 ', 'Product Rating Updated 😊 Successfully.'); 
            return redirect()->back()->with('success','Product Rating Updated 😊 Successfully');
        } else{
            connectify('error', 'Ooops 🙁', 'Something went wrong!!🙁 Please Try again.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
    public function deleteProductRatings($id)
    {
        $id         =   Crypt::decrypt($id);
        $Restricted =   Rating::where('id',$id)->delete();

        if($Restricted){
             connectify('success', 'success ', '😪 ​​​​​ Product has been deleted Successfully.😪');
            return redirect()->back()->with('success',' Product has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
public function destroy(Request $request)
   {
      Products::find($request->id)->delete();
      return redirect()->back(); 
   }
}
