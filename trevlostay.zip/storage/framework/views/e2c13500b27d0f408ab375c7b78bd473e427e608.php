
<?php $__env->startSection('title', 'All Products And Offer Images'); ?>
<?php $__env->startPush('page-style'); ?>
<!--Data Tables -->
<link href="<?php echo e(asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">All Products And Offer Images</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Products Management</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Products</li>
                </ol>
            </div>
            <div class="col-sm-3">
                <div class="btn-group float-sm-right">
                    <!-- Large Size Modal -->
                    <a href="<?php echo e(route('add-image')); ?>" class="btn btn-light waves-effect waves-light"><i class="fa fa-cog mr-1"></i>Add New Images</a>
                </div>
            </div>
        </div>
        <!-- End Breadcrumb-->
        <!-- =========Product Images Table============== -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> Products Image Table</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Product Name</th>
                                        <th>Product Images</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $Productimg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Productimgs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>


                                        <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($Productimgs->product_id == $Product['id']): ?>
                                        <td><?php echo e($Product->name); ?></td>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <td>
                                            <img src="<?php echo e(asset('images/products/'.$Productimgs->product_img)); ?>" alt="" height="50px" width="50px">

                                        </td>
                                        <td>

                                            <a href="<?php echo e(route('delete-image/{id}',['id'=>Crypt::encrypt($Productimgs->id)])); ?>" title="Delete" class="btn btn-danger"><i class="icon-trash"></i></a>
                                        </td>

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->


        <!-- ===========Offer Images Table============ -->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> Offer Images Table</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable-two" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Product Name</th>
                                        <th>Offer Images</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $Offerimg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Offerimgs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>


                                        <?php $__currentLoopData = $Products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($Offerimgs->product_id == $Product['id']): ?>
                                        <td><?php echo e($Product->name); ?></td>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <td>
                                            <img src="<?php echo e(asset('images/offers/'.$Offerimgs->offer_img)); ?>" alt="" height="50px" width="50px">

                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('delete-offer-image/{id}',['id'=>Crypt::encrypt($Offerimgs->id)])); ?>" title="Delete" class="btn btn-danger"><i class="icon-trash"></i></a>
                                        </td>

                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
<!--Data Tables js-->
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')); ?>"></script>


<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();
        $('#default-datatable-two').DataTable();

    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/pages/products/product-offer-img/all-img.blade.php ENDPATH**/ ?>