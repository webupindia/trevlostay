
<?php $__env->startSection('title', 'Add Product'); ?>
<?php $__env->startPush('page-style'); ?>
<!--text editor-->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/summernote/dist/summernote-bs4.css')); ?>" />
<style>
    .imgPreview2 img {
        padding: 8px;
        max-width: 100px;
    }

    .imgPreview3 img {
        padding: 8px;
        max-width: 100px;
    }

</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Add Product</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Products Management</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('products')); ?>">Products</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Add Product</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('add-product')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-address-book-o"></i>
                                Add New Product
                            </h4>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="marketed">Category Name</label>
                                        <select name="category_id" id="category_id" class="form-control">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger"><?php echo e($errors->first('category_id')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Product Name</label>
                                        <input type="text" name="name" class="form-control" placeholder="Enter Product Name " value="<?php echo e(old('name')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Slug</label>
                                        <input type="text" name="slug" class="form-control" placeholder="Enter Page Slug " value="<?php echo e(old('slug')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('slug')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="validationCustom01">Sale Amount</label>
                                        <input type="text" name="sale_amount" class="form-control" placeholder="Enter Sale Amount " value="<?php echo e(old('sale_amount')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('sale_amount')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="validationCustom01">Offer Amount</label>
                                        <input type="text" name="offer_amount" class="form-control" placeholder="Enter Offer Amount " value="<?php echo e(old('offer_amount')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('offer_amount')); ?></span>
                                    </div>
                                </div>
                                <input type="hidden" name="type" value="Single">

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Availability </label><br>
                                        <div class="icheck-material-primary icheck-inline">
                                            <input type="radio" id="male" name="availability" value="1" checked />
                                            <label for="male">Yes</label>
                                        </div>
                                        <div class="icheck-material-primary icheck-inline">
                                            <input type="radio" id="female" name="availability" value="0" />
                                            <label for="female">No</label>
                                        </div>
                                        <span class="text-danger"><?php echo e($errors->first('availability')); ?></span>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="marketed">Product Images</label>
                                        <div class="user-image mb-3 text-center">
                                            <div class="imgPreview2"> </div>
                                        </div>
                                        <div class="custom-file">
                                            <input type="file" name="product_img[]" class="custom-file-input" id="images2" multiple="multiple">
                                            <label class="custom-file-label" for="images">Choose Mulltiple Product image</label>
                                        </div>
                                        <span class="text-danger"><?php echo e($errors->first('slider_img')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom4">Terms & Condition</label>
                                        <textarea rows="5" cols="5" name="term_condition" class="form-control"><?php echo e(old('term_condition')); ?></textarea>
                                        <span class="text-danger"><?php echo e($errors->first('term_condition')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom4">Product Details</label>
                                        <textarea id="summernoteEditor" name="product_details" class="form-control"><?php echo e(old('product_details')); ?></textarea>
                                        <span class="text-danger"><?php echo e($errors->first('product_details')); ?></span>
                                    </div>
                                </div>


                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
<!-- jQuery -->
<!-- Dropzone JS  -->
<script src="<?php echo e(asset('admin/plugins/dropzone/js/dropzone.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/summernote/dist/summernote-bs4.min.js')); ?>"></script>
<script>
    $('#summernoteEditor').summernote({
        height: 200,
        tabsize: 2
    });

</script>
<script>
    $(document).ready(function() {
        $('#summernoteEditor').summernote({
            lang: 'es-ES'
        });
    })

</script>
<script>
    $(function() {
        // Multiple images preview with JavaScript
        var multiImgPreview = function(input, imgPreviewPlaceholder) {

            if (input.files) {
                var filesAmount = input.files.length;

                for (i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();

                    reader.onload = function(event) {
                        $($.parseHTML('<img>')).attr('src', event.target.result).appendTo(imgPreviewPlaceholder);
                    }

                    reader.readAsDataURL(input.files[i]);
                }
            }

        };

        $('#images2').on('change', function() {
            multiImgPreview(this, 'div.imgPreview2');
        });
        $('#images3').on('change', function() {
            multiImgPreview(this, 'div.imgPreview3');
        });
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/pages/products/add-product.blade.php ENDPATH**/ ?>