
<?php $__env->startSection('title', 'Product Edit'); ?>
<?php $__env->startPush('page-style'); ?>
<!--text editor-->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/summernote/dist/summernote-bs4.css')); ?>" />

<!-- Dropzone css -->
<link href="<?php echo e(asset('admin/plugins/dropzone/css/dropzone.css')); ?>" rel="stylesheet" type="text/css">
<style>
    .imgPreview img {
        padding: 8px;
        max-width: 100px;
    }
.dropdown{
   
 padding-left: 10px;

}
.dropdown-content{
    text-align: center;
}
.img-hover{
padding:10px; 
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Product Edit</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Product Management</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('products')); ?>">Product</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Product Edit</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('edit-product')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-edit"></i>
                                Product Edit
                            </h4>
                            <div class="row">

                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="marketed">Categoria</label>
                                        <select name="category_id" id="category_id" class="form-control">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($categorie->id); ?>" <?php echo e($categorie->id == $getResult->category_id ? 'selected' : ''); ?>><?php echo e($categorie->category_name); ?></option>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Product Name</label>
                                        <input type="text" name="name" class="form-control" placeholder="Enter Category Name " value="<?php echo e($getResult->name); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Slug</label>
                                        <input type="text" name="slug" class="form-control" placeholder="Enter Page Slug " value="<?php echo e($getResult->slug); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('slug')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="validationCustom01">Sale Amount</label>
                                        <input type="text" name="sale_amount" class="form-control" placeholder="Enter Sale Amount " value="<?php echo e($getResult->sale_amount); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('sale_amount')); ?></span>
                                    </div>
                                </div>
                                  <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="validationCustom01">Offer Amount</label>
                                        <input type="text" name="offer_amount" class="form-control" placeholder="Enter Offer Amount " value="<?php echo e($getResult->offer_amount); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('offer_amount')); ?></span>
                                    </div>
                                </div>
                                  <input type="hidden" name="type" value="Single">

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="">Availability </label><br>
                                        <div class="icheck-material-primary icheck-inline">
                                            <input type="radio" id="male" name="availability" value="1" checked />
                                            <label for="male">Yes</label>
                                        </div>
                                        <div class="icheck-material-primary icheck-inline">
                                            <input type="radio" id="female" name="availability" value="0" />
                                            <label for="female">No</label>
                                        </div>
                                        <span class="text-danger"><?php echo e($errors->first('availability')); ?></span>
                                    </div>
                                </div>
                                  <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="marketed">Product Images</label>
                                        <div class="user-image mb-3 text-center">
                                            <div class="imgPreview"> </div>
                                        </div>
                                        <div class="custom-file">
                                            <input type="file" name="product_img[]" class="custom-file-input" id="images" multiple="multiple">
                                            <label class="custom-file-label" for="images">Choose Mulltiple Product image</label>
                                        </div>
                                        <span class="text-danger"><?php echo e($errors->first('slider_img')); ?></span>
                                    </div>
                                </div>
                                 <?php $__currentLoopData = $Productimage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $Productimagess): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <?php if($Productimagess->product_id == $getResult->id): ?>
                                          <div class="dropdown">
                                               <img src="<?php echo e(asset('images/products/'.$Productimagess->product_img )); ?>" class="img-hover" alt="" height="50px" width="70px">
                                         <div class="dropdown-content">
                                               <a href="<?php echo e(route('delete-product-image/{id}',['id'=>Crypt::encrypt($Productimagess->id)])); ?>" title="Delete" class="btn btn-danger aDisplay"><i class="icon-trash "></i></a>
                                           </div> 
                                           </div>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom4">Terms & Condition</label>
                                        <textarea rows="5" cols="5" name="term_condition" class="form-control"><?php echo e($getResult->term_condition); ?></textarea>
                                        <span class="text-danger"><?php echo e($errors->first('term_condition')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom4">Product Details</label>
                                        <textarea id="summernoteEditor" name="product_details" class="form-control"><?php echo e($getResult->product_details); ?></textarea>
                                        <span class="text-danger"><?php echo e($errors->first('product_details')); ?></span>
                                    </div>
                                </div>
                                <input type="hidden" name="id" value="<?php echo e(Crypt::encrypt($getResult->id)); ?>">
                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>


<script>
    $(function() {
        // Multiple images preview with JavaScript
        var multiImgPreview = function(input, imgPreviewPlaceholder) {

            if (input.files) {
                var filesAmount = input.files.length;

                for (i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();

                    reader.onload = function(event) {
                        $($.parseHTML('<img>')).attr('src', event.target.result).appendTo(imgPreviewPlaceholder);
                    }

                    reader.readAsDataURL(input.files[i]);
                }
            }

        };

        $('#images').on('change', function() {
            multiImgPreview(this, 'div.imgPreview');
        });
    });

</script>
<script src="<?php echo e(asset('admin/plugins/summernote/dist/summernote-bs4.min.js')); ?>"></script>
<script>
    $('#summernoteEditor').summernote({
        height: 200,
        tabsize: 2
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/pages/products/edit-product.blade.php ENDPATH**/ ?>