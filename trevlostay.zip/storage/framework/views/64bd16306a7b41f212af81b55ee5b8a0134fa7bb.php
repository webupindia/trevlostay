
<?php $__env->startSection('title', 'Products Reviews Pages'); ?>
<?php $__env->startPush('page-style'); ?>
<!--Data Tables -->
<link href="<?php echo e(asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
   <!--Switchery-->
  <link href="<?php echo e(asset('admin/plugins/switchery/css/switchery.min.css')); ?>" rel="stylesheet" />
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" ></script>
  
  <link href="<?php echo e(asset('admin/plugins/bootstrap-switch/bootstrap-switch.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Product Reviews</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Products Management</a></li>
                     <li class="breadcrumb-item"><a href="<?php echo e(route('products')); ?>">Product</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Product Reviews</li>
                </ol>
            </div>
           
        </div>
        <!-- End Breadcrumb-->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> All Products Reviews</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Product Name</th>
                                        <th>User Name</th>
                                        <th>Review</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                          
                                <?php $__currentLoopData = $Reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                 <tr>
                                  
                                <td><?php echo e($loop->iteration); ?></td>
                                  <?php if($Products->type == 'Combo'): ?>
                                <td>
                           
                                 <?php $__currentLoopData = explode(',', $Products->name); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php $__currentLoopData = $Allproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Allproducts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php if($productName == $Allproducts['id']): ?>
                                          <div> <b>&#8680;</b> <?php echo e($Allproducts->name); ?></div>
                                      <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </td>
                             <?php else: ?>
                            
                                <td><?php echo e($Products->name); ?></td>
                             <?php endif; ?>
                             
                                <td><?php echo e($Review->name); ?></td>
                                <td><?php echo e($Review->comment); ?></td>
                              
                                <td>
                                    <input data-id="<?php echo e($Review->id); ?>" disabled class="js-switch" type="checkbox" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="InActive" data-color="#14b6ff" <?php echo e($Review->status ? 'checked' : ''); ?> >
                                </td>
                                  <td>
                                   
                                    <a href="<?php echo e(route('edit-product-review/{id}',['id'=>Crypt::encrypt($Review->id)])); ?>" title="Edit" class="btn btn-success"><i class="icon-pencil"></i></a>

                                    <a href="<?php echo e(route('delete-product-review/{id}',['id'=>Crypt::encrypt($Review->id)])); ?>" title="Delete" class="btn btn-danger"><i class="icon-trash"></i></a>
                                        </td>
                                 </tr>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
<!--Data Tables js-->
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')); ?>"></script>
 <!--Switchery Js-->
    <script src="<?php echo e(asset('admin/plugins/switchery/js/switchery.min.js')); ?>"></script>
    <script>
      var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
      $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());
       });
    </script>

    <!--Bootstrap Switch Buttons-->
    <script src="<?php echo e(asset('assets/plugins/bootstrap-switch/bootstrap-switch.min.js')); ?>"></script>


<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();

    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/pages/products/reviews/reviews.blade.php ENDPATH**/ ?>