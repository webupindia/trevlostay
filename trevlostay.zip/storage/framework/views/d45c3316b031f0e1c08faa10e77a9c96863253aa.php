
<?php $__env->startSection('title', 'Edit Supplier'); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>
<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Edit Suppliers</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">User Management</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('suppliers')); ?>">Supplier Manage</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Supplier</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form id="signupForm" action="<?php echo e(URL::route('edit-supplier')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-address-book-o"></i>
                                Edit Supplier
                            </h4>

                            <div class="form-group row">
                                <label for="input-10" class="col-sm-2 col-form-label">Full Name<span class="text-danger font-weight-bold"> *</span></label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="Enter Full Name" value="<?php echo e($getResult->name); ?>" id="input-10" name="name">
                                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                </div>
                                <label for="input-11" class="col-sm-2 col-form-label">Email<span class="text-danger font-weight-bold"> *</span></label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="Enter Email" value="<?php echo e($getResult->email); ?>" id="input-11" name="email">
                                    <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="input-12" class="col-sm-2 col-form-label">Mobile Number<span class="text-danger font-weight-bold"> *</span></label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="Enter Mobile Number" name="mobile_number" value="<?php echo e($getResult->mobile_number); ?>" id="input-12">
                                    <span class="text-danger"><?php echo e($errors->first('mobile_number')); ?></span>
                                </div>
                                <label for="input-13" class="col-sm-2 col-form-label">Password<span class="text-danger font-weight-bold"> *</span></label>
                                <div class="col-sm-4">
                                    <input type="password" class="form-control" placeholder="Enter Password" name="password" value="<?php echo e($getResult->password); ?>" id="input-13">
                                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                </div>
                            </div>
                               <div class="form-group row">
                                <label for="input-16" class="col-sm-2 col-form-label">Location<span class="text-danger font-weight-bold"> *</span></label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="Enter Location" name="location" required value="<?php echo e($getResult->location); ?>" id="input-16">
                                    <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
                                </div>
                                <label for="input-15" class="col-sm-2 col-form-label">Commissions<span class="text-danger font-weight-bold"> </span></label>
                                <div class="col-sm-4">
                                    <input type="text" class="form-control" placeholder="Enter Commissions" name="commissions" value="<?php echo e($getResult->commissions); ?>" id="input-15">
                                    <span class="text-danger"><?php echo e($errors->first('commissions')); ?></span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="input-17" class="col-sm-2 col-form-label">Company Details<span class="text-danger font-weight-bold"> *</span></label>
                                <div class="col-sm-10">
                                    <textarea class="form-control" name="company_details" rows="4" id="input-17"><?php echo e($getResult->company_details); ?>

                                    </textarea>
                                    <span class="text-danger"><?php echo e($errors->first('company_details')); ?></span>
                                    <input type="hidden" name="id" value="<?php echo e(Crypt::encrypt($getResult->id)); ?>">
                                </div>
                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>

        <!-- End Breadcrumb-->

        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/admin/pages/edit/edit-supplier.blade.php ENDPATH**/ ?>