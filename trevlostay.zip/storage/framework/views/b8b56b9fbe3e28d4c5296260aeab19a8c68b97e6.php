
<?php $__env->startSection('title', 'Vouchers Pages'); ?>
<?php $__env->startPush('page-style'); ?>
<!--Data Tables -->
<link href="<?php echo e(asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">



<style type="text/css">
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  min-width: 50px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 6px 2px;
  z-index: 1;
}

.dropdown:hover .dropdown-content {
  display: block;
}
.img-hover{
    cursor: pointer;
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Vouchers</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Vouchers Management</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Vouchers</li>
                </ol>
            </div>
            <div class="col-sm-3">
                <div class="btn-group float-sm-right">
               
                     <a href="<?php echo e(route('supplier-create-voucher')); ?>" class="btn btn-light waves-effect waves-light">Create Voucher</a>

                  
                </div>
            </div>
        </div>
        <!-- End Breadcrumb-->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> All Vouchers</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Banner</th>
                                        <th>Name</th>
                                        <th>Code</th>
                                        <th>Price</th>
                                        <th>Discount Value</th>
                                        <th>Currency</th>
                                       
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                   <?php $__currentLoopData = $Vouchers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Voucher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                      <tr>
                                          <td><?php echo e($loop->iteration); ?></td>
                                          <td>
                                            <a target="blank" href="<?php echo e(url('/images/vouchers')); ?>/<?php echo e($Voucher->images); ?>"><img src="<?php echo e(asset('images/vouchers/'.$Voucher->images)); ?>" width="100px" height="50px" /></a>

                                          </td>
                                          <td><?php echo e($Voucher->name); ?></td>
                                          <td><?php echo e($Voucher->code); ?></td>
                                          <td><?php echo e($Voucher->price); ?></td>
                                          <td><?php echo e($Voucher->discount_value); ?></td>
                                          <td><?php echo e($Voucher->currency); ?></td>
                                      
                                          </td>
                                           <td>
                                          <a href="<?php echo e(route('supplier-edit-voucher/{id}',['id'=>Crypt::encrypt($Voucher->id)])); ?>" title="Edit" class="btn btn-success"><i class="icon-pencil"></i></a>

                                          <a href="<?php echo e(route('supplier-delete-voucher/{id}',['id'=>Crypt::encrypt($Voucher->id)])); ?>"  title="Delete" class="btn btn-danger"><i class="icon-trash"></i></a>
                                        </td>
                                         
                                      </tr>
                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                   </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
<!--Data Tables js-->
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')); ?>"></script>
 <!--Switchery Js-->
    <script src="<?php echo e(asset('admin/plugins/switchery/js/switchery.min.js')); ?>"></script>
    <script>
      var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
      $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());
       });
    </script>

   

<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();

    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('supplier.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/supplier/pages/vouchers/vouchers.blade.php ENDPATH**/ ?>