<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Advertisement extends Model
{
     protected $table = 'advertisement';
      protected $fillable = ['supplier_id','name', 'type','description','ad_files','status'];
}
