@extends('supplier.layouts.master')
@section('title', 'Edit Voucher')
@push('page-style')
<!--Data Tables -->
<link href="{{asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('admin/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
 <!--Select Plugins-->
  <link href="{{asset('admin/plugins/select2/css/select2.min.css')}}" rel="stylesheet"/>
  <link href="{{asset('admin/plugins/bootstrap-datetimepicker/css/jquery.datetimepicker.css')}}" rel="stylesheet"/>

  <!--multi select-->
  <link href="{{asset('admin/plugins/jquery-multi-select/multi-select.css')}}" rel="stylesheet" type="text/css">
@endpush
@section('content')
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Edit Voucher</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Vouchers Management</a></li>
                     <li class="breadcrumb-item"><a href="{{route('supplier-vouchers')}}">Vouchers</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Voucher</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="{{ route('supplier-edit-voucher') }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-address-book-o"></i>
                                Edit Voucher
                            </h4>
                               <div class="row">
                                  <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="marketed">Category Name</label>
                                        <select name="category_id" id="category_id" class="form-control">
                                           @foreach($Categories as $categorie)
                                            <option value="{{ $categorie->id }}" {{ $categorie->id == $getResult->category_id ? 'selected' : '' }}>{{ $categorie->category_name }}</option>

                                            @endforeach
                                        </select>
                                        <span class="text-danger">{{ $errors->first('category_id') }}</span>
                                    </div>
                                </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="marketed">Voucher Type</label>
                                        <select name="types_id" id="types_id" class="form-control">
                                         @foreach($Types as $Type)
                                        <option value="{{ $Type->id }}" {{ $Type->id == $getResult->types_id ? 'selected' : '' }}>{{ $Type->types }}</option>

                                        @endforeach
                                        </select>
                                        <span class="text-danger">{{ $errors->first('types_id') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Voucher Name</label>
                                        <input type="text" name="name" class="form-control" placeholder="Enter Voucher Name" value="{{$getResult->name}}" >
                                        <span class="text-danger">{{ $errors->first('name') }}</span>
                                    </div>
                                </div>
                                 <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="validationCustom01">Voucher Code</label>
                                        <input type="text" name="code" class="form-control" placeholder="Enter Voucher Code" value="{{$getResult->code}}" >
                                        <span class="text-danger">{{ $errors->first('code') }}</span>
                                    </div>
                                </div>
                              
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="validationCustom01">Voucher Price</label>
                                        <input type="text" name="price" class="form-control" placeholder="Enter Price" value="{{$getResult->price}}" >
                                        <span class="text-danger">{{ $errors->first('price') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="validationCustom01">Discount Value</label>
                                        <input type="text" name="discount_value" class="form-control" placeholder="Enter Discount Value" value="{{$getResult->discount_value}}">
                                        <span class="text-danger">{{ $errors->first('discount_value') }}</span>
                                    </div>
                                </div>
                                 <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="validationCustom01">Currency</label>
                                        <input type="text" name="currency" class="form-control" placeholder="Enter Currency" value="{{$getResult->currency}}" >
                                        <span class="text-danger">{{ $errors->first('currency') }}</span>
                                    </div>
                                </div>
                             
                                 <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="validationCustom01">Voucher Qty</label>
                                        <input type="text" name="voucher_qty" class="form-control" placeholder="Enter Voucher Qty" value="{{$getResult->voucher_qty}}" >
                                        <span class="text-danger">{{ $errors->first('voucher_qty') }}</span>
                                    </div>
                                </div>
                                  <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="validationCustom01">Applicable Countries</label>
                                          <select name="countries_id[]" class="form-control  multiple-select" multiple="multiple">
                                          
                                          @foreach (explode(',', $getResult->countries_id) as $voucherCountry)
                                        @foreach($countries as $country)
                                        <option value="{{ $country->id }}" {{ $voucherCountry == $country->id ? 'selected' : '' }} > {{ $country->name }}</option>
                                         @endforeach
                                        @endforeach
                                        </select>

                                        <span class="text-danger">{{ $errors->first('countries_id') }}</span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                   <label>Expiry Date</label>
                                    <div >
                                     <div class="input-daterange input-group">
                                      <input type="text" id="search-from-date" value="{{$getResult->expiry_date_from}}" autocomplete="off" class="form-control" name="expiry_date_from"/>
                                      
                                      <div class="input-group-prepend">
                                       <span class="input-group-text">to</span>
                                      </div>
                                      <input type="text" id="search-from-date" value="{{$getResult->expiry_date_to}}" autocomplete="off" class="form-control" name="expiry_date_to"/>
                                       
                                     </div>
                                   </div>
                                    <span class="text-danger">{{ $errors->first('expiry_date_from') }}</span><br>
                                    <span class="text-danger">{{ $errors->first('expiry_date_to') }}</span>
                                </div>
                                 <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="validationCustom01">Banner Image</label>
                                        <input type="file" name="images" class="form-control" value="{{old('images')}}" >
                                        <span class="text-danger">{{ $errors->first('images') }}</span>
                                    </div>
                                    <img src="{{asset('images/vouchers/'.$getResult->images)}}" width="100px" height="50px" />
                                </div>
                               
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputPassword" class="">Voucher Details</label>
                                        <div class="position-relative">
                                            <textarea rows="4" class="form-control" name="details">{{$getResult->details}}
                                            </textarea>

                                            <span class="text-danger">{{ $errors->first('details') }}</span>
                                        </div>

                                    </div>
                                </div>
                                   <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputPassword" class="">Term And Condition</label>
                                        <div class="position-relative">
                                            <textarea rows="4" class="form-control" name="term_condition">{{$getResult->term_condition}}
                                            </textarea>

                                            <span class="text-danger">{{ $errors->first('term_condition') }}</span>
                                        </div>
                                     <input type="hidden" name="id" value="{{Crypt::encrypt($getResult->id)}}">
                                    </div>
                                </div>
                            </div>
                             <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

@endsection
@push('page-script')
 <script src="{{asset('admin/plugins/bootstrap-datetimepicker/js/jquery.datetimepicker.full.js')}}"></script>
  <!--Multi Select Js-->
    <script src="{{asset('admin/plugins/jquery-multi-select/jquery.multi-select.js')}}"></script>
    <script src="{{asset('admin/plugins/jquery-multi-select/jquery.quicksearch.js')}}"></script>

     <!--Select Plugins Js-->
    <script src="{{asset('admin/plugins/select2/js/select2.min.js')}}"></script>
        <script>
            /*jslint browser:true*/
            /*global jQuery, document*/

            jQuery(document).ready(function () {
                'use strict';

                jQuery('#filter-date, #search-from-date, #search-to-date').datetimepicker();
            });
        </script>
    
       <script>
        $(document).ready(function() {
            $('.single-select').select2();
      
            $('.multiple-select').select2();

        //multiselect start

            $('#my_multi_select1').multiSelect();
            $('#my_multi_select2').multiSelect({
                selectableOptgroup: true
            });

            $('#my_multi_select3').multiSelect({
                selectableHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                selectionHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                afterInit: function (ms) {
                    var that = this,
                        $selectableSearch = that.$selectableUl.prev(),
                        $selectionSearch = that.$selectionUl.prev(),
                        selectableSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selectable:not(.ms-selected)',
                        selectionSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selection.ms-selected';

                    that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
                        .on('keydown', function (e) {
                            if (e.which === 40) {
                                that.$selectableUl.focus();
                                return false;
                            }
                        });

                    that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                        .on('keydown', function (e) {
                            if (e.which == 40) {
                                that.$selectionUl.focus();
                                return false;
                            }
                        });
                },
                afterSelect: function () {
                    this.qs1.cache();
                    this.qs2.cache();
                },
                afterDeselect: function () {
                    this.qs1.cache();
                    this.qs2.cache();
                }
            });

          });

    </script>
    @endpush
