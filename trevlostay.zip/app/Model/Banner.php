<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    protected $table = 'banner';
     protected $fillable = ['supplier_id','name', 'type','caption','banner','status'];
}
