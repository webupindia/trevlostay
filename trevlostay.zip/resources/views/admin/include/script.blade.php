    <script src="{{asset('admin/js/jquery.min.js')}}"></script> 
    <script src="{{asset('admin/js/popper.min.js')}}"></script> 
    <script src="{{asset('admin/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('admin/plugins/simplebar/js/simplebar.js')}}"></script>
    <script src="{{asset('admin/js/sidebar-menu.js')}}"></script>
    <script src="{{asset('admin/js/app-script.js')}}"></script>
