@extends('admin.layouts.master')
@section('title', 'Advertisement Pages')
@push('page-style')
<!--Data Tables -->
<link href="{{asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<!--Switchery-->
<link href="{{asset('admin/plugins/switchery/css/switchery.min.css')}}" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<link href="{{asset('admin/plugins/bootstrap-switch/bootstrap-switch.min.css')}}" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
@if(Session::has('errors'))
<script>
    $(document).ready(function() {
        $("#modal-animation-8").modal('show');
    });

</script>
@endif


<style type="text/css">
    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        min-width: 50px;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        padding: 6px 2px;
        z-index: 1;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    .img-hover {
        cursor: pointer;
    }

    .pointer {
        cursor: pointer;
    }

</style>
@endpush
@section('content')
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Advertisement </h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Advertisement </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Advertisement</li>
                </ol>
            </div>
            <div class="col-sm-3">
                <div class="btn-group float-sm-right">


                    <button type="button" class="btn btn-light waves-effect waves-light" data-toggle="modal" data-target="#modal-animation-8">Create Advertisement</button>
                </div>
            </div>
        </div>
        <!-- End Breadcrumb-->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> All Advertisement</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Image And Video</th>
                                        <th>Name</th>
                                        <th>Author</th>
                                        <th>type</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($Advertisement as $Advertisements)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>
                                            @if ($Advertisements->type == 'images')
                                            <img src="{{asset('advertisement/'.$Advertisements->ad_files)}}" data-toggle="modal" data-target="#fullprimarymodal" class="pointer" width="100px" height="50px"/>
                                            @else
                                            <video width="80" class="pointer">
                                                <source src="{{asset('advertisement/'.$Advertisements->ad_files)}}" type="video/mp4">
                                            </video>
                                            @endif

                                        </td>

                                        <td>{{ $Advertisements->name }}</td>
                                         @if (!(empty($Advertisements->supplier_id)))

                                                @foreach($SupplierName as $SupplierNames)
                                                @if($Advertisements->supplier_id == $SupplierNames['id'])
                                                <td>{{ $SupplierNames->name }}</td>
                                                @endif
                                                @endforeach
                                            @else

                                              <td>Admin</td>
                                               
                                           @endif
                                        <td>{{ $Advertisements->type }}</td>
                                        <td>{{ $Advertisements->description }}</td>

                                        <td>
                                            <input data-id="{{$Advertisements->id}}" class="js-switch" type="checkbox" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="InActive" data-color="#14b6ff" {{ $Advertisements->status ? 'checked' : '' }} ></td>


                                        <td>
                                            <a href="{{route('edit-advertisement/{id}',['id'=>Crypt::encrypt($Advertisements->id)])}}" title="Edit" class="btn btn-success"><i class="icon-pencil"></i></a>

                                            <a href="{{route('delete-advertisement/{id}',['id'=>Crypt::encrypt($Advertisements->id)])}}" title="Delete" class="btn btn-danger"><i class="icon-trash"></i></a>
                                        </td>

                                    </tr>



                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<!-- ------Create Advertisement Model------- -->
<div class="modal fade" id="modal-animation-8">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content animated swing">
            <div class="modal-header">
                <h5 class="modal-title">
                    <p class="form-header text-uppercase">
                        <i class="fa fa-address-book-o"></i>
                        Create Advertisement
                    </p>
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form action="{{route('create-advertisement')}}" method="post" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="validationCustom01">Advertisement Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Enter Advertisement Name " value="{{old('name')}}">
                                <span class="text-danger">{{ $errors->first('name') }}</span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="validationCustom01">Type</label>
                                <select name="type" id="type" class="form-control" onchange="yesnoCheck(this);">

                                    <option value="">Choose Type</option>
                                    <option value="videos" @if (old('type')=="videos" ) {{ 'selected' }} @endif>Videos</option>
                                    <option value="images" @if (old('type')=="images" ) {{ 'selected' }} @endif>Images</option>

                                </select>
                                <span class="text-danger">{{ $errors->first('type') }}</span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group ">
                                <label for="validationCustom01">Images Or Videos</label>
                                <input type="file" name="ad_files[]" class="form-control" value="{{old('ad_files')}}" multiple="multiple">
                                <span class="text-danger">{{ $errors->first('ad_files') }}</span>
                            </div>
                        </div>


                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputPassword" class="">Description</label>
                                <div class="position-relative">
                                    <textarea rows="4" class="form-control" name="description">{{ old('description') }}
                                    </textarea>

                                    <span class="text-danger">{{ $errors->first('description') }}</span>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="form-footer">
                        <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<!--  -->
@endsection
@push('page-script')
<!--Data Tables js-->
<script src="{{asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')}}"></script>
<!--Switchery Js-->
<script src="{{asset('admin/plugins/switchery/js/switchery.min.js')}}"></script>
<script>
    var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
    $('.js-switch').each(function() {
        new Switchery($(this)[0], $(this).data());
    });

</script>

<!--Bootstrap Switch Buttons-->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.min.js"></script>
<script>
    $(function() {
        toastr.options = {
            "closeButton": true,
            "newestOnTop": true,
            "positionClass": "toast-top-right"
        };
        $('.js-switch').change(function() {
            var status = $(this).prop('checked') == true ? 1 : 0;
            var user_id = $(this).data('id');

            $.ajax({
                type: "GET",
                dataType: "json",
                url: 'change-advertisement-status',
                data: {
                    'status': status,
                    'user_id': user_id
                },
                success: function(data) {
                    console.log(data.success)

                    location.reload();
                }
            });
        })
    })

</script>

<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();

    });

</script>

@endpush
