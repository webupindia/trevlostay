@extends('admin.layouts.master')
@section('title', 'Products Pages')
@push('page-style')
<!--Data Tables -->
<link href="{{asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<!--Switchery-->
<link href="{{asset('admin/plugins/switchery/css/switchery.min.css')}}" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<link href="{{asset('admin/plugins/bootstrap-switch/bootstrap-switch.min.css')}}" rel="stylesheet">

<style type="text/css">
    .dropdown-item:hover {
        background-color: grey;
    }

</style>
@endpush
@section('content')
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-8">
                <h4 class="page-title">Products</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Products Management</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Products</li>
                </ol>
            </div>
            <div class="col-sm-4">
                <div class="btn-group float-sm-right">
                    <a href="{{route('add-product')}}" class="btn btn-light waves-effect waves-light">Add New Product</a>
                </div>
            </div>
        </div>
        <!-- End Breadcrumb-->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> All Products</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Product Images</th>
                                        <th>Product Name</th>
                                        <th>Author</th>
                                        <th>Category</th>
                                        <th>Sale Amount</th>
                                        <th>Offer Amount</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($Products as $key=> $Product)
                                    <tr id="deleteRow">
                                        <td>{{ $loop->iteration }}</td>
                                        <td>
                                            @foreach($Productimage as $key2 => $Productimagess)
                                            @if($Productimagess->product_id == $Product['id'])
                                            <span class="dropdown">
                                                <img src="{{asset('images/products/'.$Productimagess->product_img )}}" class="img-hover" alt="" height="50px" width="50px">
                                            </span>
                                            @endif
                                            @endforeach
                                        </td>

                                        <td>{{ $Product->name}}</td>

                                        @if (!(empty($Product->supplier_id)))
                                        @foreach($SupplierName as $key4 => $SupplierNames)
                                        @if($Product->supplier_id == $SupplierNames['id'])
                                        <td>{{ $SupplierNames->name }}</td>
                                        @endif
                                        @endforeach
                                        @else
                                        <td>Admin</td>
                                        @endif

                                        @foreach($Categories as $key5 => $Category)
                                        @if($Product->category_id == $Category['id'])
                                        <td>{{ $Category->category_name }}</td>
                                        @endif
                                        @endforeach

                                        <td><del>{{ $Product->sale_amount}}</del> &#36;</td>

                                        <td>{{ $Product->offer_amount}} &#36;</td>

                                        <td>
                                            <input data-id="{{$Product->id}}" class="js-switch" type="checkbox" data-onstyle="success" data-offstyle="danger" data-toggle="toggle" data-on="Active" data-off="InActive" data-color="#14b6ff" {{ $Product->status ? 'checked' : '' }} >
                                        </td>

                                        <td>
                                            <div class="dropdown">
                                                <a href="javascript:void();" class="dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown">
                                                    <i class="icon-options"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <a class="dropdown-item" href="{{route('product-review/{id}',['id'=>Crypt::encrypt($Product->id)])}}" title="View Review">View Review </a>

                                                    <a class="dropdown-item" href="{{route('product-rating/{id}',['id'=>Crypt::encrypt($Product->id)])}}" title="View Review">View Rating</a>

                                                    <a class="dropdown-item " href="{{route('edit-product/{id}',['id'=>Crypt::encrypt($Product->id)])}}" title="Edit Product">Edit Product</a>

                                                    <a class="dropdown-item button" href="#" data-id="{{$Product->id}}" title="Delete Product">Delete Product</a>

                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                    @endforeach
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

@endsection
@push('page-script')
<!--Data Tables js-->
<script src="{{asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')}}"></script>
<!--Switchery Js-->
<script src="{{asset('admin/plugins/switchery/js/switchery.min.js')}}"></script>
<!--Bootstrap Switch Buttons-->
<script src="{{asset('assets/plugins/bootstrap-switch/bootstrap-switch.min.js')}}"></script>
<script>
    var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
    $('.js-switch').each(function() {
        new Switchery($(this)[0], $(this).data());
    });

</script>

<script>
    $(function() {
        $('.js-switch').change(function() {
            var status = $(this).prop('checked') == true ? 1 : 0;
            var user_id = $(this).data('id');

            $.ajax({
                type: "GET",
                dataType: "json",
                url: 'change-product-status',
                data: {
                    'status': status,
                    'user_id': user_id
                },
                success: function(data) {
                    console.log(data.success)

                    location.reload();
                }
            });
        })
    })

</script>
<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();

    });

</script>
<script src="{{asset('admin/plugins/alerts-boxes/js/sweetalert.min.js')}}"></script>
<script type="text/javascript">
    $(document).on('click', '.button', function(e) {
        e.preventDefault();
        var id = $(this).data('id');
        var whichtr = $(this).closest("#deleteRow");
        swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover this file!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        type: "GET",
                        url: "destroy",
                        data: {
                            id: id
                        },
                        success: function(data) {
                            swal("Poof! Your Data has been deleted!", {
                                icon: "success",
                            });
                            $(whichtr).remove();
                        }
                    });
                } else {
                    swal("Your imaginary file is safe!");
                }

            });
    });

</script>
@endpush
