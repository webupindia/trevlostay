 <!--Start footer-->
		<footer class="footer">
			<div class="container">
				<div class="text-center">
					 <strong>Copyright &copy; {{date('Y')}} <a href="#"> {{ env('APP_NAME') }}</a>.</strong> All rights
				</div>
			</div>
		</footer><!--End footer-->