<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Products;
use App\Model\Productimg;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;


class ProductOfferImgController extends Controller
{
	
       public function add () {
        $Products = Products::all();
        return view('admin.pages.products.product-offer-img.add-img', ['Products' => $Products]);
    }


	public function AddProductImg(Request $request)
    {
    	 $this->validate($request, [
                'product_id'        => 'required',
                'product_img.*'     => 'mimes:jpeg,jpg,png|max:2048', 
        
              ]);

        $images      =  array();
        $product_id  =  $request->product_id;

        if($files = $request->file('product_img'))
        {
            foreach($files as $file) 
            {
               $productimgname     =   time().rand(1,100).'.'.$file->extension();
               $destinationPath = public_path('images/products');

                if($file->move($destinationPath, $productimgname))
                {
                    $images[]   =   $productimgname;
                    $saveResult   =   Productimg::create([
                    	'product_id' => $product_id,
                    	'product_img' => $productimgname
                    ]);   
                }
            }
        }

	       connectify('success', 'Haa Haa 😊 ', 'New Images  Added 😊 Successfully.');
	       return redirect()->route('products')->with('success','😊 New  Images Added  Added  😊 Successfully 😊');
    }

      public function deleteProductImg($id)
    {
            $id          =   Crypt::decrypt($id);
            $Restricted         = Productimg::findOrFail($id);
            $image_path         = public_path("\images\products\\") .$Restricted->product_img;
            if(File::exists($image_path)) {
                File::delete($image_path);
            }
            else{
                $Restricted->delete();
            }
            $Restricted->delete();
        if($Restricted){
             connectify('success', 'success ', '😪 ​​​​​ Product Image has been deleted Successfully.😪');
            return redirect()->back()->with('success','  Product Image has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
    
}
