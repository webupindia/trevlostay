
<?php $__env->startSection('title','Reset Password'); ?>
<?php $__env->startSection('content'); ?>
<div class="height-100v d-flex align-items-center justify-content-center">
	<div class="card card-authentication1 mb-0">
		<div class="card-body">
		 <div class="card-content p-2">
		  <div class="card-title text-uppercase pb-2">Reset Password</div>
		    <p class="pb-2">Please enter your email address. You will receive a link to create a new password via email.</p>
		    <form  action="<?php echo e(route('forget')); ?>" method="post" enctype="multipart/form-data">
		    	<?php echo csrf_field(); ?>
			  <div class="form-group">
			  <label for="exampleInputEmailAddress" class="">Email Address</label>
			   <div class="position-relative has-icon-right">
				  <input type="text" id="exampleInputEmailAddress" name="email" class="form-control input-shadow" placeholder="Email Address">
				  <div class="form-control-position">
					  <i class="icon-envelope-open"></i>
				  </div>
			   </div>
			     <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
			  </div>
			 
			  <button type="submit" class="btn btn-light btn-block mt-3">Reset Password</button>
			 </form>
		   </div>
		  </div>
		   <div class="card-footer text-center py-3">
		    <p class="text-warning mb-0">Return to the <a href="<?php echo e(route('lv_admin')); ?>"> Login Page</a></p>
		  </div>
	     </div>
	     </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.login_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dashnox\resources\views/backend/auth/forget-password.blade.php ENDPATH**/ ?>