	<!--Start sidebar-wrapper-->
   <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo ">
      <a href="<?php echo e(route('dashboard')); ?>">
       <img src="<?php echo e(asset('storage/logo/small_logo.png')); ?>" class="logo-icon" alt="logo icon">
       <h5 class="logo-text"> Admin</h5>
     </a>
   </div>
   <ul class="sidebar-menu">
      <li class="sidebar-header">MAIN NAVIGATION</li>
      <li class="active">
        <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect ">
          <i class="zmdi zmdi-view-dashboard"></i> <span>Dashboard</span>
        </a>
    </ul>
   
   </div>
   <!--End sidebar-wrapper--><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/backend/include/sidebar.blade.php ENDPATH**/ ?>