<?php

namespace App\Model\Vouchers;

use Illuminate\Database\Eloquent\Model;

class Vouchers extends Model
{
    protected $table = 'vouchers';

      protected $fillable = ['category_id','types_id','name','code','applicable_countries', 'price','discount_value','details','currency', 'term_condition','expiry_date','voucher_qty' ];
}



