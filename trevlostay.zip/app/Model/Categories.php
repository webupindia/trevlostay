<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use App\Model\products;
class Categories extends Model
{
     protected $table = 'categories';

     protected $fillable = ['category_name','slug', 'thumbnail','banner'];
     
     public function products(){
      return $this->hasMany(products::class);
    }
}
