<?php

namespace App\Http\Controllers\Supplier;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Model\Advertisement;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Auth;

class AdvertisementController extends Controller
{
	public function getAllAdvertisement()
    {
         $supplier= Auth::guard('supplier')->user()->id;
        $Advertisement = Advertisement::latest()->where('supplier_id', $supplier)->orderBy('id', 'desc')->get();
        if(count($Advertisement)>0){
            return view('supplier.pages.advertisement.advertisement',['Advertisement'=>$Advertisement]);
        } else {
            connectify('error', 'Ooops 🙁', 'No Data Found ');
             return view('supplier.pages.advertisement.advertisement',['Advertisement'=>$Advertisement]);
        }
    }
    public function CreateAdvertisement(Request $request)
    {
    	 $this->validate($request, [
                'name'        => 'required|unique:advertisement',
                'type'        => 'required',
                'description' => 'required',
                'ad_files'     => 'required', 
                'ad_files.*'   => 'mimes:jpeg,jpg,png,mp4,ogx,oga,ogv,ogg,webm|max:10240', 
               
              ]);
        $ad_files      =  array();
        $name         =  $request->name;
        $type         =  $request->type;
        $description  =  $request->description;
        if($files = $request->file('ad_files'))
        {
            foreach($files as $file)
             {
                $ad_name     = time().rand(1,100).'.'.$file->extension();
                $destinationPath = public_path('advertisement');
                
                if($file->move($destinationPath, $ad_name))
                {

                    $ad_files[]   =   $ad_name;

                     $saveResult   =   Advertisement::create([
                    	'supplier_id'  => Auth::guard('supplier')->user()->id,
                        'name'         => $name,
                    	'type'         => $type,
                    	'description'  => $description,
                    	'ad_files'     => $ad_name
                    ]);
                }
            }
        }

	     connectify('success', 'Haa Haa 😊 ', 'New Advertisement  Created 😊 Successfully.');
	     return redirect()->route('supplier-advertisement')->with('success','😊 New  Advertisement Added  Added  😊 Successfully 😊');  
    }
     public function editAdvertisementView($id)
    {

       try {
           $decrypted    = Crypt::decrypt($id);
           $getResult    = Advertisement::where('Id',$decrypted)->first();
           $getResults   = Advertisement::select('id')->latest()->get();

           if(!is_null($getResult)){
            return view('supplier.pages.advertisement.edit-advertisement',['getResult'=>$getResult,'getResults'=>$getResults]);
           } else {
            return redirect()->back()->with('error','Oops ! No Data found for specific id');
           }

       } catch (\Illuminate\Contracts\Encryption\DecryptException $e) {
           abort(404);
       }
    }
     public function putAdvertisement(Request $request)
    {
        $this->validate($request, [
                'name'        => 'required',
                'type'        => 'required',
                'description' => 'required',
                'ad_files'    => 'nullable|mimes:jpeg,jpg,png,mp4,ogx,oga,ogv,ogg,webm|max:10240', 
         ]);
     
        $id                = Crypt::decrypt($request['id']);
        $name              = strip_tags($request['name']);
        $type              = strip_tags($request['type']);
        $description       =  $request['description'];
        
         $Advertisement = Advertisement::find($id);

       if($request->ad_files != ''){        
          $path = public_path().'/advertisement\\';

          //code for remove old file
          if($Advertisement->ad_files != ''  && $Advertisement->ad_files != null){
               $file_old = $path.$Advertisement->ad_files;
               unlink($file_old);
          }
          //upload new file
          $file = $request->ad_files;
          $filename =  time().'.'.$file->extension();
          $file->move($path, $filename);
          //for update in table
          $Advertisement->update(['ad_files' => $filename]);
        }

        $updatePage  = Advertisement::where('id',$id)->update([
            'name'             => $name,
            'type'             => $type,
            'description'      => $description,
        ]);
        
             connectify('success', 'Haa Haa 😊 ', ' Advertisement Updated 😊 Successfully.'); 
            return redirect()->route('supplier-advertisement')->with('success','Advertisement Updated 😊 Successfully');

    }
   public function deleteAdvertiesementImg($id)
    {
        $id         =   Crypt::decrypt($id);
        $Advertisement =   Advertisement::findOrFail($id);
       
        $Advertisement_path = public_path("/advertisement\\") .$Advertisement->ad_files;
            if(File::exists($Advertisement_path)) {
                File::delete($Advertisement_path);
            }else{
   
               $Advertisement->delete();
            }
               $Advertisement->delete();

        if($Advertisement){
             connectify('success', 'success ', '😪 ​​​​​ Advertisement has been deleted Successfully.😪');
            return redirect()->back()->with('success','  Advertisement has been deleted  successfully');
        } else {
              connectify('error', 'Oops 💁', '! Something went wrong 💁.');
            return redirect()->back()->with('error','Oops ! Something went wrong');
        }
    }
    
}
