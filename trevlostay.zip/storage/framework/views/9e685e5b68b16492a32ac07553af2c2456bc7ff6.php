
<?php $__env->startSection('title', 'Create Voucher'); ?>
<?php $__env->startPush('page-style'); ?>
<!--Data Tables -->
<link href="<?php echo e(asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('admin/plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
 <!--Select Plugins-->
  <link href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet"/>
  <link href="<?php echo e(asset('admin/plugins/bootstrap-datetimepicker/css/jquery.datetimepicker.css')); ?>" rel="stylesheet"/>

  <!--multi select-->
  <link href="<?php echo e(asset('admin/plugins/jquery-multi-select/multi-select.css')); ?>" rel="stylesheet" type="text/css">

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Create Voucher</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Vouchers Management</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(route('supplier-vouchers')); ?>">Vouchers</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Create Voucher</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('supplier-create-voucher')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-address-book-o"></i>
                                Create New Voucher
                            </h4>
                            <div class="row">
                                  <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="marketed">Category Name</label>
                                        <select name="category_id" id="category_id" class="form-control">
                                            <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger"><?php echo e($errors->first('category_id')); ?></span>
                                    </div>
                                </div>
                                  <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="marketed">Voucher Type</label>
                                        <select name="types_id" id="types_id" class="form-control">
                                            <?php $__currentLoopData = $Types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value2->id); ?>"><?php echo e($value2->types); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="text-danger"><?php echo e($errors->first('types_id')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Voucher Name</label>
                                        <input type="text" name="name" class="form-control" placeholder="Enter Voucher Name" value="<?php echo e(old('name')); ?>" >
                                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Voucher Code</label>
                                        <input type="text" name="code" class="form-control" placeholder="Enter Voucher Code" value="<?php echo e(old('code')); ?>" >
                                        <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
                                    </div>
                                </div>
                                    <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Applicable Countries</label>
                                        <select name="countries_id[]" class="form-control  multiple-select" multiple="multiple">
                                          <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->id); ?>"><?php echo e($country->nicename); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                        <span class="text-danger"><?php echo e($errors->first('countries_id')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Voucher Price</label>
                                        <input type="text" name="price" class="form-control" placeholder="Enter Price" value="<?php echo e(old('price')); ?>" >
                                        <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Discount Value</label>
                                        <input type="text" name="discount_value" class="form-control" placeholder="Enter Discount Value" value="<?php echo e(old('discount_value')); ?>">
                                        <span class="text-danger"><?php echo e($errors->first('discount_value')); ?></span>
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Currency</label>
                                        <input type="text" name="currency" class="form-control" placeholder="Enter Currency" value="<?php echo e(old('currency')); ?>" >
                                        <span class="text-danger"><?php echo e($errors->first('currency')); ?></span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="validationCustom01">Voucher Qty</label>
                                        <input type="text" name="voucher_qty" class="form-control" placeholder="Enter Voucher Qty" value="<?php echo e(old('voucher_qty')); ?>" >
                                        <span class="text-danger"><?php echo e($errors->first('voucher_qty')); ?></span>
                                    </div>
                                </div>
                                 <div class="col-md-6">
                                   <label>Expiry Date</label>
                                    <div >
                                     <div class="input-daterange input-group">
                                      <input type="text" id="search-from-date" value="<?php echo e(old('expiry_date_from')); ?>" autocomplete="off" class="form-control" name="expiry_date_from"/>
                                      
                                      <div class="input-group-prepend">
                                       <span class="input-group-text">to</span>
                                      </div>
                                      <input type="text" id="search-from-date" value="<?php echo e(old('expiry_date_to')); ?>" autocomplete="off" class="form-control" name="expiry_date_to"/>
                                       
                                     </div>
                                   </div>
                                    <span class="text-danger"><?php echo e($errors->first('expiry_date_from')); ?></span><br>
                                    <span class="text-danger"><?php echo e($errors->first('expiry_date_to')); ?></span>
                                </div>
                                 
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="validationCustom01">Banner Image</label>
                                        <input type="file" name="images" class="form-control" value="<?php echo e(old('images')); ?>" >
                                        <span class="text-danger"><?php echo e($errors->first('images')); ?></span>
                                    </div>
                                </div>
                        
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputPassword" class="">Voucher Details</label>
                                        <div class="position-relative">
                                            <textarea rows="4" class="form-control" name="details"><?php echo e(old('details')); ?>

                                            </textarea>

                                            <span class="text-danger"><?php echo e($errors->first('details')); ?></span>
                                        </div>

                                    </div>
                                </div>
                                   <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="exampleInputPassword" class="">Term And Condition</label>
                                        <div class="position-relative">
                                            <textarea rows="4" class="form-control" name="term_condition"><?php echo e(old('term_condition')); ?>

                                            </textarea>

                                            <span class="text-danger"><?php echo e($errors->first('term_condition')); ?></span>
                                        </div>

                                    </div>
                                </div>
                            </div>

                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
 <script src="<?php echo e(asset('admin/plugins/bootstrap-datetimepicker/js/jquery.datetimepicker.full.js')); ?>"></script>
  <!--Multi Select Js-->
    <script src="<?php echo e(asset('admin/plugins/jquery-multi-select/jquery.multi-select.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/jquery-multi-select/jquery.quicksearch.js')); ?>"></script>

     <!--Select Plugins Js-->
    <script src="<?php echo e(asset('admin/plugins/select2/js/select2.min.js')); ?>"></script>
        <script>
            /*jslint browser:true*/
            /*global jQuery, document*/

            jQuery(document).ready(function () {
                'use strict';

                jQuery('#filter-date, #search-from-date, #search-to-date').datetimepicker();
            });
        </script>
    
       <script>
        $(document).ready(function() {
            $('.single-select').select2();
      
            $('.multiple-select').select2();

        //multiselect start

            $('#my_multi_select1').multiSelect();
            $('#my_multi_select2').multiSelect({
                selectableOptgroup: true
            });

            $('#my_multi_select3').multiSelect({
                selectableHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                selectionHeader: "<input type='text' class='form-control search-input' autocomplete='off' placeholder='search...'>",
                afterInit: function (ms) {
                    var that = this,
                        $selectableSearch = that.$selectableUl.prev(),
                        $selectionSearch = that.$selectionUl.prev(),
                        selectableSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selectable:not(.ms-selected)',
                        selectionSearchString = '#' + that.$container.attr('id') + ' .ms-elem-selection.ms-selected';

                    that.qs1 = $selectableSearch.quicksearch(selectableSearchString)
                        .on('keydown', function (e) {
                            if (e.which === 40) {
                                that.$selectableUl.focus();
                                return false;
                            }
                        });

                    that.qs2 = $selectionSearch.quicksearch(selectionSearchString)
                        .on('keydown', function (e) {
                            if (e.which == 40) {
                                that.$selectionUl.focus();
                                return false;
                            }
                        });
                },
                afterSelect: function () {
                    this.qs1.cache();
                    this.qs2.cache();
                },
                afterDeselect: function () {
                    this.qs1.cache();
                    this.qs2.cache();
                }
            });

        

          });

    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('supplier.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/supplier/pages/vouchers/create-voucher.blade.php ENDPATH**/ ?>