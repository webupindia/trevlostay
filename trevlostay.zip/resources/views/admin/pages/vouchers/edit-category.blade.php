@extends('admin.layouts.master')
@section('title', 'Edit Voucher category ')
@section('content')
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-12">
                <h4 class="page-title">Edit Voucher category</h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Vouchers Management</a></li>
                    <li class="breadcrumb-item"><a href="{{route('voucher-categories')}}">Categories</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit category</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <form action="{{ route('edit-voucher-category') }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <h4 class="form-header text-uppercase">
                                <i class="fa fa-address-book-o"></i>
                                Edit Voucher category
                            </h4>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="validationCustom01">Category Name</label>
                                        <input type="text" name="category_name" class="form-control" placeholder="Enter Category " value="{{$getResult->category_name}}">
                                        <span class="text-danger">{{ $errors->first('category_name') }}</span>
                                        <input type="hidden" name="id" value="{{Crypt::encrypt($getResult->id)}}">
                                    </div>
                                </div>
                            </div>
                            <div class="form-footer">
                                <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

@endsection
