    <script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('admin/js/popper.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/plugins/simplebar/js/simplebar.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/sidebar-menu.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/app-script.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\dashnox\resources\views/backend/include/script.blade.php ENDPATH**/ ?>