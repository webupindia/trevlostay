<html>
<head>
<title>Dashnox</title>
</head>	
<body>
<h1 style="margin-top:20%; text-align: center;">Welcome To Dashnox</h1>
<a href="<?php echo e(route('lv_admin')); ?>" style="border:none; width: 90px; text-decoration: none; background-color: green; padding: 10px 10px; color: white; display: block; margin:auto;" >Admin Login</a>
	</body>
</html><?php /**PATH C:\xampp\htdocs\dashnox\resources\views/welcome.blade.php ENDPATH**/ ?>