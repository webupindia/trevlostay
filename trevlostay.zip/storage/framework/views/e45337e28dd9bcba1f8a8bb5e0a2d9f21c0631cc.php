
<?php $__env->startSection('title', 'Banner Home Page '); ?>
<?php $__env->startPush('page-style'); ?>
<!--Data Tables -->
<link href="<?php echo e(asset('admin/plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<!--Switchery-->
<link href="<?php echo e(asset('admin/plugins/switchery/css/switchery.min.css')); ?>" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<link href="<?php echo e(asset('admin/plugins/bootstrap-switch/bootstrap-switch.min.css')); ?>" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<?php if(Session::has('errors')): ?>
<script>
    $(document).ready(function() {
        $("#modal-animation-8").modal('show');
    });

</script>
<?php endif; ?>


<style type="text/css">
    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        min-width: 50px;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        padding: 6px 2px;
        z-index: 1;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    .img-hover {
        cursor: pointer;
    }

    .pointer {
        cursor: pointer;
    }

</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="clearfix"></div>

<div class="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumb-->
        <div class="row pt-2 pb-2">
            <div class="col-sm-9">
                <h4 class="page-title">Banner </h4>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javaScript:void();">Home Management </a></li>
                    <li class="breadcrumb-item active" aria-current="page">Banner</li>
                </ol>
            </div>
            <div class="col-sm-3">
                <div class="btn-group float-sm-right">


                    <button type="button" class="btn btn-light waves-effect waves-light" data-toggle="modal" data-target="#modal-animation-8">Add New Banner</button>
                </div>
            </div>
        </div>
        <!-- End Breadcrumb-->
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header"><i class="fa fa-table"></i> All Banners</div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table id="default-datatable" class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <th>Image And Video</th>
                                        <th>Name</th>
                                       
                                        <th>type</th>
                                        <th>Caption</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                     <?php $__currentLoopData = $Banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Homebanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <?php if($Homebanner->type == 'images'): ?>
                                            <img src="<?php echo e(asset('images/home/banner/'.$Homebanner->banner)); ?>" data-toggle="modal" data-target="#fullprimarymodal" class="pointer" width="100px" height="50px"/>
                                            <?php else: ?>
                                            <video width="80" class="pointer">
                                                <source src="<?php echo e(asset('images/home/banner/'.$Homebanner->banner)); ?>" type="video/mp4">
                                            </video>
                                            <?php endif; ?>

                                        </td>

                                        <td><?php echo e($Homebanner->name); ?></td>
                                       
                                        <td><?php echo e($Homebanner->type); ?></td>
                                        <td><?php echo e($Homebanner->caption); ?></td>

                                    
                                        <td>
                                            <a href="<?php echo e(route('supplier-edit-banner/{id}',['id'=>Crypt::encrypt($Homebanner->id)])); ?>" title="Edit" class="btn btn-success"><i class="icon-pencil"></i></a>

                                            <a href="<?php echo e(route('supplier-delete-banner/{id}',['id'=>Crypt::encrypt($Homebanner->id)])); ?>" title="Delete" class="btn btn-danger"><i class="icon-trash"></i></a>
                                        </td>

                                    </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- End Row-->
        <!--start overlay-->
        <div class="overlay toggle-menu"></div>
        <!--end overlay-->
    </div>
    <!-- End container-fluid-->

</div>
<!--End content-wrapper-->

<!-- ------Create Advertisement Model------- -->
<div class="modal fade" id="modal-animation-8">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content animated swing">
            <div class="modal-header">
                <h5 class="modal-title">
                    <p class="form-header text-uppercase">
                        <i class="fa fa-address-book-o"></i>
                       Add Banner
                    </p>
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <form action="<?php echo e(route('supplier-add-banner')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="validationCustom01">Banner Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Enter Banner Name " value="<?php echo e(old('name')); ?>">
                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="validationCustom01">Type</label>
                                <select name="type" id="type" class="form-control" onchange="yesnoCheck(this);">

                                    <option value="">Choose Type</option>
                                    <option value="videos" <?php if(old('type')=="videos" ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Videos</option>
                                    <option value="images" <?php if(old('type')=="images" ): ?> <?php echo e('selected'); ?> <?php endif; ?>>Images</option>

                                </select>
                                <span class="text-danger"><?php echo e($errors->first('type')); ?></span>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group ">
                                <label for="validationCustom01">Images Or Videos</label>
                                <input type="file" name="banner" class="form-control" value="<?php echo e(old('banner')); ?>">
                                <span class="text-danger"><?php echo e($errors->first('banner')); ?></span>
                            </div>
                        </div>


                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="exampleInputPassword" class="">Caption</label>
                                <div class="position-relative">
                                    <textarea rows="4" class="form-control" name="caption"><?php echo e(old('caption')); ?>

                                    </textarea>

                                    <span class="text-danger"><?php echo e($errors->first('caption')); ?></span>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="form-footer">
                        <button type="submit" class="btn btn-success float-right"><i class="fa fa-check-square-o"></i> SAVE</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<!--  -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('page-script'); ?>
<!--Data Tables js-->
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/bootstrap-datatable/js/dataTables.buttons.min.js')); ?>"></script>
<!--Switchery Js-->
<script src="<?php echo e(asset('admin/plugins/switchery/js/switchery.min.js')); ?>"></script>
<script>
    var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
    $('.js-switch').each(function() {
        new Switchery($(this)[0], $(this).data());
    });

</script>

<!--Bootstrap Switch Buttons-->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.min.js"></script>

<script>
    $(document).ready(function() {
        //Default data table
        $('#default-datatable').DataTable();

    });

</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('supplier.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\travelostay\resources\views/supplier/pages/home-page/banner.blade.php ENDPATH**/ ?>